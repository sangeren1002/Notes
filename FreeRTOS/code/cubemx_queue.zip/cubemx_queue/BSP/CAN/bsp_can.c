/* Includes ------------------------------------------------------------------*/
#include "bsp_can.h"
#include "canfestival.h"
#include "bsp_timer.h"
#include "motor_control.h"
#include "GlobalVar.h"

/* CAN1发送与接收数据帧头 */
CAN_TxHeaderTypeDef				CAN1_TxHeaderMessage;
CAN_RxHeaderTypeDef				CAN1_RxHeaderMessage;

/* CAN1发送与接收实际数据 */
CAN_Msgdata can1_tx_msg;
CAN_Msgdata can1_rx_msg;

/*****************************************************************************
 * 函 数 名  : canInit
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月8日
 * 函数功能  : CAN1初始化函数
 * 输入参数  : 无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
u8 canInit(void)
{
	MX_CAN1_Init();
	CAN_Filter_Init();
	return 0;
}

/*****************************************************************************
 * 函 数 名  : CAN_Filter_Init
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月8日
 * 函数功能  : 初始化can过滤器参数
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void CAN_Filter_Init(void)
{
	CAN_FilterTypeDef CAN_FilterInitStructure;

	CAN_FilterInitStructure.FilterActivation       	= ENABLE; 
	CAN_FilterInitStructure.FilterBank				= 0;
	CAN_FilterInitStructure.FilterFIFOAssignment   	= CAN_FILTER_FIFO0;
	CAN_FilterInitStructure.FilterIdHigh           	= 0x0000;
	CAN_FilterInitStructure.FilterIdLow           	= 0x0000;
	CAN_FilterInitStructure.FilterMaskIdHigh        = 0x0000;
	CAN_FilterInitStructure.FilterMaskIdLow         = 0x0000;
	CAN_FilterInitStructure.FilterMode				= CAN_FILTERMODE_IDMASK;
	CAN_FilterInitStructure.FilterScale            	= CAN_FILTERSCALE_32BIT;
	CAN_FilterInitStructure.SlaveStartFilterBank	= 14;
	
	if(HAL_CAN_ConfigFilter(&hcan1, &CAN_FilterInitStructure) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	if(HAL_CAN_Start(&hcan1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	if(HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
}

/*****************************************************************************
 * 函 数 名  : CAN_Init
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月8日
 * 函数功能  : can功能测试初始化函数
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void CAN_Init(void)
{
	CAN_FilterTypeDef myFilter;
	myFilter.FilterBank = 0;
	myFilter.SlaveStartFilterBank 	= 14;
    myFilter.FilterMode             = CAN_FILTERMODE_IDMASK;
    myFilter.FilterScale            = CAN_FILTERSCALE_32BIT;
    myFilter.FilterIdHigh           = 0x0000;
    myFilter.FilterIdLow            = 0x0000;
    myFilter.FilterMaskIdHigh       = 0x0000;
    myFilter.FilterMaskIdLow        = 0x0000;
    myFilter.FilterFIFOAssignment   = CAN_FILTER_FIFO0;
    myFilter.FilterActivation       = ENABLE;
    HAL_CAN_ConfigFilter(&hcan1,&myFilter);

	if(HAL_CAN_ConfigFilter(&hcan1, &myFilter) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	if(HAL_CAN_Start(&hcan1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	if(HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

}

/*****************************************************************************
 * 函 数 名  : canSend
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月8日
 * 函数功能  : canopen发送数据函数
 * 输入参数  : CAN_HandleTypeDef *hcan  can句柄指针
               Message *m               can数据发送结构体指针
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
u8 canSend(CAN_HandleTypeDef *hcan,Message *m)
{
	unsigned char i;
	CAN_TxHeaderTypeDef TxMessage;
	
	TxMessage.StdId = (uint32_t)(m->cob_id);
	TxMessage.ExtId = 0x00;
	TxMessage.RTR = m->rtr; 							  
	TxMessage.IDE = CAN_ID_STD; 						  
	TxMessage.DLC = 8; 	
	TxMessage.DLC = m->len; 		
	for(i=0;i<m->len;i++)								  
	{
		can1_tx_msg.Data[i] = m->data[i];
	}
	if(HAL_CAN_AddTxMessage(&hcan1, &TxMessage, can1_tx_msg.Data, (uint32_t*)CAN_TX_MAILBOX0) != HAL_OK)
	{
	 	printf("[Error] canSend() StdId:%d\r\n",TxMessage.StdId);
		return 1;
		//_Error_Handler(__FILE__, __LINE__);
	}
	return 0;
}
CANOpen_Message CAN1_Rx_m;
Message RxMSG = Message_Initializer;
/*****************************************************************************
 * 函 数 名  : HAL_CAN_RxFifo0MsgPendingCallback
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月8日
 * 函数功能  : can队列0挂起中断回调函数
 * 输入参数  : CAN_HandleTypeDef *hcan  can操作句柄指针
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
	if(hcan->Instance == CAN1)
	{
		/* 得到can接收数据 */
		 HAL_CAN_GetRxMessage(hcan,CAN_RX_FIFO0, &CAN1_RxHeaderMessage, can1_rx_msg.Data);
		
		/* 处理can接收数据按照 canDispatch函数要求的数据格式*/
		 RxMSG.cob_id = CAN1_RxHeaderMessage.StdId;
		 RxMSG.len = CAN1_RxHeaderMessage.DLC;
		 RxMSG.rtr = CAN1_RxHeaderMessage.RTR;
		 memcpy(RxMSG.data,can1_rx_msg.Data,CAN1_RxHeaderMessage.DLC);
	}
   AnalysisMessagefromDriver();
//	SEGGER_RTT_printf(0, "can master revcive data!!!!!!!!!!!!\n");
	canDispatch(CANOpenMasterObject, &(RxMSG));
}


/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
