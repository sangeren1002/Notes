/***********************************************************************************
 * 文 件 名   : bsp_timer.c
 * 负 责 人   : jishubao
 * 创建日期   : 2019年3月6日
 * 文件描述   : 板载定时器功能
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/
#include "bsp_timer.h"
#include "bsp_usart.h"
#include "bsp_can.h"
#include "bsp_gpio.h"
#include "sys_config.h"
#include "motor_control.h"
#include "bsp_SR04M.h"
#include "iwdg.h"

#ifdef CANOPEN_MY
#include <stdbool.h>
#include "canfestival.h"
#include "timer.h"

#endif

#ifdef CANOPEN_MY
static TIMEVAL last_time_set = TIMEVAL_MAX;

/**
  * @brief  setTimer
  * @param  value:Set time value 0x0000-0xffff
  * @retval NONE
  */
void setTimer(TIMEVAL value)
{
	__HAL_TIM_SetAutoreload(&htim4, value);
}
/**
  * @brief  getElapsedTime
  * @param  NONE
	* @retval TIMEVAL:Return current timer value
  */
TIMEVAL getElapsedTime(void)
{
	uint16_t timer = __HAL_TIM_GetCounter(&htim4);
	
//	printf("timercnt:%d  last_time_set:%d val:%d\r\n",timer,last_time_set,timer > last_time_set ? timer - last_time_set : last_time_set - timer);
	return timer > last_time_set ? timer - last_time_set : last_time_set - timer; 	
}

/**
  * @brief  TIM4_start
  * @param  NONE
  * @retval NONE
  */
void TIM4_start(void)
{
		MX_TIM4_Init();
		HAL_TIM_IC_Start_IT (&htim4, TIM_CHANNEL_1);
}
/**
  * @brief  initTimer
  * @param  NONE
  * @retval NONE
  */
void initTimer(void)
{
		TIM4_start();
}


#endif

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	static uint16_t cnt = 0;
	char buff[20]={0};
	
	
	if(htim==(&htim4))//
	{
		cnt++;
		last_time_set = __HAL_TIM_GET_COUNTER(htim);
			printf("htim4 last_time_set:%d\r\n",last_time_set);
		//USART1_Send_DMA(buff,strlen(buff));
		TimeDispatch();
	}



}

void HAL_TIM4_IRQHandler(void)
{

}
/*****************************************************************************
 * 函 数 名  : HAL_TIM_PeriodElapsedCallback
 * 负 责 人  : 纪书保
 * 创建日期  : 2019年3月6日
 * 函数功能  : 定时器定时10MS完成回调函数
 * 输入参数  : TIM_HandleTypeDef *htim  定时器操作句柄
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
//	static u8 tim = 0;
	static u32 cnt = 0;
//	static u32 timex = 1;
	static u32 wdi_cnt = 0;
   if(htim==(&htim3))//定时器3定时10ms时间到
	{
	 
		canSend(&hcan1,&Can_Msg_SYNCMY);
//	if(HW1_SW_STOP || HW2_SW_STOP)
//	{		
//		 MotionHalts();
//         AbnormalReporting(1,1,3);
//	}
//		 if(cnt%10==0)//100ms周期发送一次超声波命令
//		 {
//			 Send_SR04M_CMD((u8*)cmdbuf,LEN_SR04M_CMD);//发送超声波测距命令
//		 }
//		 if(cnt%20==0)
//		 {
//			
//			WDI_HD_Refresh(wdi_cnt%2);
//			  wdi_cnt++;
//		 }
//		 if(cnt%50==0)//500ms喂狗
//		 {
//		 	HAL_IWDG_Refresh(&hiwdg);
//		 }
		 cnt++; 
	}
//	if(htim==(&htim4))//定时器3定时10ms时间到
//	{
//		last_time_set = __HAL_TIM_GET_COUNTER(htim);
//	
//		TimeDispatch();
//		
////		wdi_cnt++;
////		if(wdi_cnt%20==0)
////			printf("htim4:%d\r\n",last_time_set);
//		//USART1_Send_DMA("htim4\r\n",7);
//	}

}
void user_pwm_setvalue(uint16_t value,uint32_t chanenel)
{
	TIM_OC_InitTypeDef sConfigOC;
	
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = value;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, chanenel) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	HAL_TIM_PWM_Start(&htim1,chanenel);

}

