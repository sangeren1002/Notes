/***********************************************************************************
 * 文 件 名   : bsp_usart.c
 * 负 责 人   : jishubao
 * 创建日期   : 2019年3月6日
 * 文件描述   : 板载串口功能文件
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/
#include "bsp_usart.h"
#include "bsp_gpio.h"
#include "usart.h"
#include "string.h"
#include "FreeRTOS.h"
#include "queue.h"

USART_RECEIVETYPE UsartType;
USART_RECEIVETYPE Usart2Type;
USART_RECEIVETYPE Usart3Type;
USART_RECEIVETYPE Usart4Type;
USART_RECEIVETYPE Usart5Type;
uint8_t recvfromPCbuf[RX_LEN];//上位机通信串口接收缓存



/*****************************************************************************
 * 函 数 名  : HAL_UART_TxCpltCallback
 * 负 责 人  : jishubao
 * 创建日期  : 2019年2月27日
 * 函数功能  : 串口发送完成回调函数
 * 输入参数  : UART_HandleTypeDef *huart  串口操作句柄
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  :   使用DMA时需要将发送完成状态更新，否则DMA会出现bug

*****************************************************************************/
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    huart->gState = HAL_UART_STATE_READY;
}

/*****************************************************************************
 * 函 数 名  : UsartReceive_IDLE
 * 负 责 人  : jishubao
 * 创建日期  : 2019年2月19日
 * 函数功能  : 串口接受空闲中断处理函数
 * 输入参数  : UART_HandleTypeDef *huart  串口句柄
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void UsartReceive_IDLE(UART_HandleTypeDef *huart)  
{  
    uint32_t temp;  
	BaseType_t pxHigherPriorityTaskWoken = pdFALSE;

    if((__HAL_UART_GET_FLAG(huart,UART_FLAG_IDLE) != RESET))  
    {   
        __HAL_UART_CLEAR_IDLEFLAG(huart);  
        HAL_UART_DMAStop(huart);  
        temp = (*huart).hdmarx->Instance->NDTR;
        if(huart->Instance==USART1)
        {
            UsartType.RX_Size = RX_LEN - temp;   
            UsartType.RX_flag = 1;  
            HAL_UART_Receive_DMA(huart,UsartType.RX_pData,RX_LEN);  
			//就向队列发送接收到的数据
//	if((UsartType.RX_flag)&&(myQueue01Handle!=NULL))
//	{
//		xQueueSendFromISR(myQueue01Handle,(void*)&UsartType,&pxHigherPriorityTaskWoken);//向队列中发送数据
//		
//		UsartType.RX_flag =0;	
//		memset(&UsartType,0,sizeof(USART_RECEIVETYPE));//清除数据接收缓冲区USART_RX_BUF,用于下一次数据接收
//	
//		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);//如果需要的话进行一次任务切换
//	}
//			xQueueSendFromISR(myQueue01Handle,(void *)&UsartType,&pxHigherPriorityTaskWoken);
//			if(pxHigherPriorityTaskWoken == pdTRUE)
//				portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);

        }
        else if(huart->Instance==USART2)
        {
            Usart2Type.RX_Size = RX_LEN - temp;   
            Usart2Type.RX_flag = 1;  
            HAL_UART_Receive_DMA(huart,Usart2Type.RX_pData,RX_LEN);  
//			xQueueSendFromISR(myQueue02Handle,(void *)Usart2Type.RX_pData,&pxHigherPriorityTaskWoken);
//			if(pxHigherPriorityTaskWoken == pdTRUE)
//				portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
        }                
        else if(huart->Instance==USART3)
        {
            Usart3Type.RX_Size =  RX_LEN - temp;   
            Usart3Type.RX_flag=1;  
            HAL_UART_Receive_DMA(huart,Usart3Type.RX_pData,RX_LEN); 
//			xQueueSendFromISR(myQueue03Handle,(void *)Usart3Type.RX_pData,&pxHigherPriorityTaskWoken);
//			if(pxHigherPriorityTaskWoken == pdTRUE)
//				portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
        } 
		else if(huart->Instance==UART4)
        {
            Usart4Type.RX_Size =  RX_LEN - temp;   
            Usart4Type.RX_flag=1;  
            HAL_UART_Receive_DMA(huart,Usart4Type.RX_pData,RX_LEN); 
//			xQueueSendFromISR(myQueue04Handle,(void *)Usart4Type.RX_pData,&pxHigherPriorityTaskWoken);
//			if(pxHigherPriorityTaskWoken == pdTRUE)
//				portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
        }    
		else if(huart->Instance==UART5)
        {
            Usart5Type.RX_Size =  RX_LEN - temp;   
            Usart5Type.RX_flag=1;  
            HAL_UART_Receive_DMA(huart,Usart5Type.RX_pData,RX_LEN); 
//			xQueueSendFromISR(myQueue05Handle,(void *)Usart5Type.RX_pData,&pxHigherPriorityTaskWoken);
//			if(pxHigherPriorityTaskWoken == pdTRUE)
//				portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
        }     
    } 
 
}

/*****************************************************************************
 * 函 数 名  : Analysis_Serial_Data
 * 负 责 人  : jishubao
 * 创建日期  : 2019年2月19日
 * 函数功能  : 串口接收数据直接转发函数
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
 void Analysis_Serial_Data(void)
 {
	 if(UsartType.RX_flag)		 // Receive flag
	 {	
		 UsartType.RX_flag=0;	 // clean flag
		 HAL_UART_Transmit_DMA(&huart1, UsartType.RX_pData, UsartType.RX_Size);
 
	 }
	 if(Usart2Type.RX_flag) 	 // Receive flag
	 {	
		 Usart2Type.RX_flag=0;	 // clean flag
		 HAL_UART_Transmit_DMA(&huart2, Usart2Type.RX_pData, Usart2Type.RX_Size);
	 }	  
	 if(Usart3Type.RX_flag) 	 // Receive flag
	 {	
		 Usart3Type.RX_flag=0;	 // clean flag
		 HAL_UART_Transmit_DMA(&huart3, Usart3Type.RX_pData, Usart3Type.RX_Size);
	 }
	 if(Usart4Type.RX_flag) 	 // Receive flag
	 {	
		 Usart4Type.RX_flag=0;	 // clean flag
		 HAL_UART_Transmit_DMA(&huart4, Usart4Type.RX_pData, Usart4Type.RX_Size);
	 }
	 if(Usart5Type.RX_flag) 	 // Receive flag
	 {	
		 Usart5Type.RX_flag=0;	 // clean flag
		 HAL_UART_Transmit_DMA(&huart5, Usart5Type.RX_pData, Usart5Type.RX_Size);
	 }
 }
 uint8_t USART1_Send_DMA(uint8_t *data,uint8_t len)
{
	uint32_t cnt;
	
	cnt = 0;
//	uint8_t buff[50] = {0};
//	if(len<50)
//		memcpy(buff,data,len);
	 /* modify begin by jishubao, 2019-02-27, Mantis号:1 
	原因: 发送前需要判断串口状态，串口状态在串口发送完成回调函数里更新*/
	while(HAL_UART_STATE_READY != huart1.gState && cnt< HAL_MAX_DELAY-1)cnt++; 
	if (HAL_UART_Transmit_DMA(&huart1, data, len) != HAL_OK)
	{
		/* Transfer error in transmission process */                                                                                  
		//Error_Handler(); 
		return 1;
	}
	HAL_Delay(2);
	return 0;
}
uint8_t USART1_Read_DMA(uint8_t *data,uint8_t *len)
{
	if(UsartType.RX_flag)		 // Receive flag
	{
		UsartType.RX_flag = 0;
		*len = UsartType.RX_Size;
		memcpy(data,UsartType.RX_pData,UsartType.RX_Size);
		return 0;
	}
	else
		return 1;
}
uint8_t USART2_Send_DMA(uint8_t *data,uint8_t len)
{
	 uint32_t cnt = 0;;
	 /* modify begin by jishubao, 2019-02-27, Mantis号:1 
	原因: 发送前需要判断串口状态，串口状态在串口发送完成回调函数里更新*/
	while(HAL_UART_STATE_READY != huart2.gState && cnt< HAL_MAX_DELAY-1)cnt++; 
	if (HAL_UART_Transmit_DMA(&huart2, data, len) != HAL_OK)
	{
		/* Transfer error in transmission process */                                                                                  
		//Error_Handler();   
		return 1;
	}
	return 0;
}
uint8_t USART2_Read_DMA(uint8_t *data,uint8_t *len)
{
	if(Usart2Type.RX_flag)		 // Receive flag
	{
		Usart2Type.RX_flag = 0;
		*len = Usart2Type.RX_Size;
		memcpy(data,Usart2Type.RX_pData,Usart2Type.RX_Size);
		return 0;
	}
	else
		return 1;
}
void Enable_BSP_USART_IT(void)
{
    /* 清除串口空闲中断标志 */
    __HAL_UART_CLEAR_IDLEFLAG(&huart1);
    __HAL_UART_CLEAR_IDLEFLAG(&huart2);
    __HAL_UART_CLEAR_IDLEFLAG(&huart3);
//    __HAL_UART_CLEAR_IDLEFLAG(&huart4);
//    __HAL_UART_CLEAR_IDLEFLAG(&huart5);

    /* 配置非阻塞模式下串口 DMA接收 */
    HAL_UART_Receive_DMA(&huart1, UsartType.RX_pData, RX_LEN);
    HAL_UART_Receive_DMA(&huart2, Usart2Type.RX_pData, RX_LEN); 
    HAL_UART_Receive_DMA(&huart3, Usart3Type.RX_pData, RX_LEN);
//    HAL_UART_Receive_DMA(&huart4, Usart4Type.RX_pData, RX_LEN);
//    HAL_UART_Receive_DMA(&huart5, Usart5Type.RX_pData, RX_LEN);

    /* 使能串口空闲中断 */
    __HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE);
//    __HAL_UART_ENABLE_IT(&huart4, UART_IT_IDLE);
//    __HAL_UART_ENABLE_IT(&huart5, UART_IT_IDLE);
}
/*****************************************************************************
 * 函 数 名  : PC_Data_Analysis
 * 负 责 人  : jishubao
 * 创建日期  : 2018年11月21日
 * 函数功能  : 上位机命令分析
 * 输入参数  : char *recvfromPCbuf  从上位机接收命令室的缓存首地址
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
uint8_t PC_Data_Analysis(uint8_t *recvfromPCbuf)
{
//    float vall = 0,valr = 0;
//    u16 crccheck = 0;
//    u16 temp_crc = 0;

//    if((recvfromPCbuf[0]==0x55) && (recvfromPCbuf[1]==0xaa)) //帧头2字节
//    {
//        length = recvfromPCbuf[4];      //得到字长度  
//        memcpy(&temp_crc, &recvfromPCbuf[2], sizeof(temp_crc)); //得到modbus crc-16校验位
//        crccheck = GetCRC16((uint8_t*)&recvfromPCbuf[6],length);     //计算当前数据包CRC校验值
//        if(crccheck!= temp_crc)     //判断CRC校验位是否正确
//        {
//            return 0;
//        }
//        LED_RUN_Toggle();

//        switch (recvfromPCbuf[5])       //判断MsgID
//        {
//            case MOTOR_CTL_MSGID_CMD:   //电机控制指令 0x01
//                memcpy(&vall, &recvfromPCbuf[6], sizeof(vall));         //得到上位机命令的左电机速度
//                memcpy(&valr, &recvfromPCbuf[10], sizeof(valr));        //得到上位机命令的右电机速度
//                Set_Speed((float)vall,(float)valr);                     //设置左右电机速度              
//                break;
//            case BATTARY_MONITOR_MSGID_CMD:                 //电池信息指令 0x02
//                RequestBatteryInformation(&battarymsg);     //得到电池信息
//                Date_Up_Load(BATTARY_MONITOR_MSGID_CMD);
//                break;	
//            //case OPEN_YUNTAI_CMD:                 //请求开启云台 0x07
//                //Set_Yuntai(recvfromPCbuf[6]);         //设置云台状态
//                //break;
//            case ALARM_CMD:                         //请求开启报警三色灯 0x08
//                Set_Alarm(recvfromPCbuf[6]);        //设置三色灯状态
//                break;
//            case ENABLE_CHARGE_CMD:               //无线充电使能指令 0x09
//                //Wireless_Charging_Status(recvfromPCbuf[6]);//设置无线充电状态  
//                break;
//            default:
//                break;
//        }
//    }
	return 0;

}

//实现printf函数重定向到串口1，即支持printf信息到USART1
 #ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the EVAL_COM1 and Loop until the end of transmission */
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
 
  return ch;
}

