﻿/***********************************************************************************
 * 文 件 名   : bsp_SR04M.h
 * 负 责 人   : jishubao
 * 创建日期   : 2019年2月20日
 * 文件描述   : bsp_SR04M.h 的头文件
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/

#ifndef __BSP_SR04M_H__
#define __BSP_SR04M_H__
#include "stm32f4xx_hal.h"
#include "main.h"
#include "sys_config.h"


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

#define LEN_SR04M_CMD 10 //超声波数据的CMD 长度
extern  const u8 cmdbuf[10];


HAL_StatusTypeDef Get_Ultrasonic_Sensor_Distance(u16 *dis);
HAL_StatusTypeDef Send_SR04M_CMD(u8 *cmd,u8 len);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __BSP_SR04M_H__ */

