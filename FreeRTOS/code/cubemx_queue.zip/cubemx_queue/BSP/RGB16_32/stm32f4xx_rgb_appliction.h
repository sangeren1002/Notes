#ifndef __APPLICTION_H
#define	__APPLICTION_H

#endif /* __STM32F10x_RGB_APPLICTION_H */
