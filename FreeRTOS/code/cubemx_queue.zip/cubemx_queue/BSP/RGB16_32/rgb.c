#include "rgb.h"
#include "delay.h"
#include "bsp_gpio.h"
#include <string.h>
#include <math.h>

uint8_t LED_X,LED_Y;            //LED�����������(���ڵߵ���ʾ��
uint8_t LED_RAM[LED_byte];    /**************************************��ʾ������*/ 

const u8 scan = MATRIX_HEIGHT / 2;
uint32_t bufferA[MATRIX_SIZE];
//const int waits[] = { 5, 10, 20, 40, 80, 160, 320, 640 };
u8 Red_Write  [MAX_light/8] = {0};    //����  
u8 Green_Write[MAX_light/8] = {0};  
u8 Blue_Write [MAX_light/8] = {0};  
u8 Display_PWM[MATRIX_MODULE*MATRIX_HEIGHT*2][3]={
0x00,
};
//const u16 waits[] =   { 1, 2, 6, 24, 80, 160, 340, 760, 3500};
const int waits[] = { 5, 10, 15, 20, 25, 30, 35, 40 };
const u16 waitb[] =   { 0, 1, 4, 32, 128, 256, 512, 1024, 2048};
static rotationDegrees rotation_Degrees = rotation0; //����


const unsigned char gImage_image[64] = { /* 0X00,0X18,0X40,0X00,0X20,0X00,0X00,0X39, */
0x00,0x00,0x00,0xC0,0x38,0x0E,0x8E,0x33,0x7C,0x1F,0x51,0x1E,0xFE,0xBF,0xA0,0x0F,
0xFE,0xBF,0xC0,0x08,0xFE,0xBF,0x78,0x08,0xFE,0xBF,0x1F,0x08,0xFC,0xBF,0x03,0x04,
0xFC,0xFF,0x01,0x04,0xF8,0x7F,0x02,0x02,0xF8,0x1F,0x04,0x01,0xF0,0x07,0x88,0x00,
0xE0,0x01,0x50,0x00,0xB8,0x00,0x20,0x00,0x0C,0x00,0x00,0x00,0x07,0x00,0x00,0x00,

};
const u8 Image21[] = //����
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0C,0x30,0x12,0x48,0x11,0x88,
0x10,0x08,0x08,0x10,0x04,0x20,0x02,0x40,0x01,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

const u8 Imagelove[][34] = {
//ʵ��01��
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0C,0x30,0x1E,0x78,0x1F,0xF8,
0x1F,0xF8,0x0F,0xF0,0x07,0xE0,0x03,0xC0,0x01,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},/*"C:\Users\Administrator\Desktop\BMP����\���� - ����.BMP",0*/

//ʵ��02��
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x06,0xC0,0x0F,0xE0,
0x0F,0xE0,0x07,0xC0,0x03,0x80,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},/*"C:\Users\Administrator\Desktop\BMP����\���� - ���� (2).BMP",0*/

//ʵ��03��
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x80,
0x07,0xC0,0x03,0x80,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}/*"δ�����ļ�",0*/

};
const u8 Image49[] = //ʵ��01��
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0C,0x30,0x1E,0x78,0x1F,0xF8,0x1F,0xF8,0x0F,0xF0,0x07,0xE0,0x03,0xC0,0x01,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*"C:\Users\Administrator\Desktop\BMP����\���� - ����.BMP",0*/
const u8 Image59[] = //ʵ��02��
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x06,0xC0,0x0F,0xE0,0x0F,0xE0,0x07,0xC0,0x03,0x80,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*"C:\Users\Administrator\Desktop\BMP����\���� - ���� (2).BMP",0*/

const u8 Image69[] = //ʵ��03��
{0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x80,0x07,0xC0,0x03,0x80,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*"δ�����ļ�",0*/


 

s8 _abs(s8 n)
{
	return n * ( (n>>8<<1) +1);
}
void MY_RGB_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	 /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

	GPIO_InitStruct.Pin = RGB_PIN_B1_Pin|RGB_PIN_G1_Pin|RGB_PIN_R1_Pin|RGB_PIN_G2_Pin 
                          |RGB_PIN_R2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	 /*Configure GPIO pins : PCPin PCPin */
  GPIO_InitStruct.Pin = RGB_PIN_B2_Pin|RGB_PIN_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PBPin PBPin */
  GPIO_InitStruct.Pin = RGB_PIN_A_Pin|RGB_PIN_C_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = RGB_PIN_STR_Pin|RGB_PIN_SCK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = RGB_PIN_OE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(RGB_PIN_OE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, RGB_PIN_B1_Pin|RGB_PIN_G1_Pin|RGB_PIN_R1_Pin|RGB_PIN_G2_Pin 
                          |RGB_PIN_R2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, RGB_PIN_B2_Pin|RGB_PIN_B_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, RGB_PIN_A_Pin|RGB_PIN_C_Pin|LED_RUN_Pin|LED_ALARM_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, RGB_PIN_STR_Pin|RGB_PIN_SCK_Pin|FillLight_Pin|Reserved1_Pin 
                          |Reserved2_Pin|ArmLight_Pin|EarLight_Pin|LegLight_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port, RGB_PIN_OE_Pin, GPIO_PIN_RESET);

}
//LED IO��ʼ��
//void RGB_Init(void)
//{
//    GPIO_InitTypeDef GPIO_Initure;
//	__HAL_RCC_GPIOG_CLK_ENABLE();           //����GPIOFʱ��
//	__HAL_RCC_GPIOG_CLK_ENABLE();           //����GPIOFʱ��
//	
//	
//	GPIO_Initure.Pin=GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8; //PF9,10
//    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
//    GPIO_Initure.Pull=GPIO_PULLUP;          //����
//    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
//    HAL_GPIO_Init(GPIOG,&GPIO_Initure);
//	
//	GPIO_Initure.Pin=GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8; //PF9,10
//    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
//    GPIO_Initure.Pull=GPIO_PULLUP;          //����
//    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
//    HAL_GPIO_Init(GPIOF,&GPIO_Initure);

//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_SET);
//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_A,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_A,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_C,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_SCK,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_STR,GPIO_PIN_RESET);	
//	
//	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_R1,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_G1,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B1,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_R2,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_G2,GPIO_PIN_RESET);	
//	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B2,GPIO_PIN_RESET);	
//}
/***********           ��ɫ ��ɫ ��ɫ �ֽ�����  ��ɫ            **************/  
void RGB_Write_Byte(u8 RED,u8 GREEN,u8 BLUE,u8 Page)  
{  
	u8 i;        //��ʼ��  
	u8 r,g,b;    //��ԭɫ����  
	r=RED;                  //��ֵ  
	g=GREEN;  
	b=BLUE;  
	SCK_L;                  //����ʱ��  
	if(Page)  //Page Ϊ1ʱ��д���ϰ벿��  
		for(i=0;i<8;i++)  
		{  
			((r & 0x01) ==0x01)? R1_H:R1_L;  //SET_RGB_PIN_R1(1):SET_RGB_PIN_R1(0);
			((g & 0x01) ==0x01)? G1_H:G1_L;  //SET_RGB_PIN_G1(1):SET_RGB_PIN_G1(0);
			((b & 0x01) ==0x01)? B1_H:B1_L;  //SET_RGB_PIN_B1(1):SET_RGB_PIN_B1(0);

			//            R1=r & 0x01;  //д���ɫ����  
			//            G1=g & 0x01;  //д����ɫ����  
			//            B1=b & 0x01;  //д����ɫ����  
			r=r>>1;  
			g=g>>1;  
			b=b>>1;  
			SCK_H;  
			SCK_L;  
	    }  
	else    //д���°벿��  
		 for(i=0;i<8;i++)  
		 {  
			 ((r & 0x01) ==0x01)? R2_H:R2_L;  
			 ((g & 0x01) ==0x01)? G2_H:G2_L;  
			 ((b & 0x01) ==0x01)? B2_H:B2_L;  
			 r=r>>1;  
			 g=g>>1;  
			 b=b>>1;  
			 SCK_H;  
			 SCK_L;  
		 }  
} 
void RGB_Write(unsigned char Line)  //д������  
{  
	u8 j;  
	u8 Page;  
	LE_L;       //  
	if(Line<9)  
	Page=1;  
	else  
	Page=0;  
	OE_H;       //  
	switch (Line)  
	{  
		case 1:A_L;B_L;C_L;break;  
		case 5:A_L;B_L;C_H;break;  
		case 3:A_L;B_H;C_L;break;  
		case 7:A_L;B_H;C_H;break;  
		case 2:A_H;B_L;C_L;break;  
		case 6:A_H;B_L;C_H;break;  
		case 4:A_H;B_H;C_L;break;  
		case 8:A_H;B_H;C_H;break;  
		case 9:A_L;B_L;C_L;break;  
		case 13:A_L;B_L;C_H;break;  
		case 11:A_L;B_H;C_L;break;  
		case 15:A_L;B_H;C_H;break;  
		case 10:A_H;B_L;C_L;break;  
		case 14:A_H;B_L;C_H;break;  
		case 12:A_H;B_H;C_L;break;  
		case 16:A_H;B_H;C_H;break;  
		default:OE_H;//A=1;D=1;C=1;  
	}  
#if (MAX_light==32)   //д��һ������  
	 for(j=0;j<4;j++)  
	 {  
	 	RGB_Write_Byte(Red_Write[j],Green_Write[j],Blue_Write[j],Page);  
	 }  
#else  
	 for(j=0;j<8;j++)  
	 {  
	 	RGB_Write_Byte(Red_Write[j],Green_Write[j],Blue_Write[j],Page);  
	 }  
#endif  
	 LE_H;        //����д������  
	 LE_L;  
	 OE_L;  
	 delay_ms(1);  
	 OE_H;  
} 
/**
 * strobes / shows a line for a n*nop amount of time.
 */
void showLine(u16 amount) 
{
	u16 c;
	STROBE;
	DISP2_ON;
	for (c=0; c<amount; c++);// __nop();//__NOP /*asm("nop")*/;
	DISP2_OFF;
	if(c <255){
		c = 256 - amount;
		for (c=0; c<amount; c++) ;//__NOP /*asm("nop")*/;
	}

}
/**
  * @brief  �Ҷ���ʾ������
  * @param  None
  * @retval None
  */
void display_PWM(void) 
	{
	u8 s = 0,plane = 0;
	u8 Display_Cache[64][3];
	u8 Display_Cache1[64][3];

	#if(MATRIX_WIDTH == 32)
		for(plane = 0; plane < scan; plane ++) //��ɨ�� ɨ��8��
		{
				u8 num,a;
			  for(a=0;a<32;a++)
			  {
					//ѭ����Ҫ 87.33 us
					u16 number;
					number = plane *32 + a;
				  Display_Cache[a][0]=Display_PWM[number][0];
				  Display_Cache[a][1]=Display_PWM[number][1];
				  Display_Cache[a][2]=Display_PWM[number][2];
				  Display_Cache[a+32][0]=Display_PWM[number+512][0];
				  Display_Cache[a+32][1]=Display_PWM[number+512][1];
				  Display_Cache[a+32][2]=Display_PWM[number+512][2];
					
				  Display_Cache1[a][0]=Display_PWM[number+256][0];
				  Display_Cache1[a][1]=Display_PWM[number+256][1];
				  Display_Cache1[a][2]=Display_PWM[number+256][2];
				  Display_Cache1[a+32][0]=Display_PWM[number+768][0];
				  Display_Cache1[a+32][1]=Display_PWM[number+768][1];
				  Display_Cache1[a+32][2]=Display_PWM[number+768][2];
				}
			  setRow(plane);  // ��ѡ��
			  for(num=8;num>0;num--) //ÿһ��ɨ��8��
			  {
					for(a=0;a<MATRIX_MODULE;a++) //ѭ����0 ~ 32  ѭ����Ҫ68.25 us
					{
						  u16 aaa = s*32+a;
							if((Display_Cache[aaa][0] & 0x80) == 0x80)
								//MTX_PORTc->BSRR = MTX_PR0;
								SET_RGB_PIN_R1(1);
							else
								//MTX_PORTc->BRR  = MTX_PR0; 	
								SET_RGB_PIN_R1(0);
							if((Display_Cache[aaa][1] & 0x80) == 0x80)
								//MTX_PORT->BSRR = MTX_PG0;
								SET_RGB_PIN_G1(1);
							else
								//MTX_PORT->BRR  = MTX_PG0;
								SET_RGB_PIN_G1(0);
							if((Display_Cache[aaa][2] & 0x80) == 0x80)
								//MTX_PORTc->BSRR = MTX_PB0;
								SET_RGB_PIN_B1(1);
							else
								SET_RGB_PIN_B1(0);
								//MTX_PORTc->BRR  = MTX_PB0;

							if((Display_Cache1[aaa][0] & 0x80) == 0x80)
								//MTX_PORTc->BSRR = MTX_PR1;
								SET_RGB_PIN_R2(1);
							else
								SET_RGB_PIN_R2(0);
								//MTX_PORTc->BRR  = MTX_PR1; 
							if((Display_Cache1[aaa][1] & 0x80) == 0x80)
								//MTX_PORT->BSRR = MTX_PG1;
								SET_RGB_PIN_G2(1);
							else
								SET_RGB_PIN_G2(0);
								//MTX_PORT->BRR  = MTX_PG1;
							if((Display_Cache1[aaa][2] & 0x80) == 0x80)
								//MTX_PORTc->BSRR = MTX_PB1;
								SET_RGB_PIN_B2(1);
							else
								//MTX_PORTc->BRR  = MTX_PB1;
								SET_RGB_PIN_B2(0);
							CLK_TOGGLE;
					}
					for(a=0;a<64;a++)
					{
						Display_Cache[a][0] = Display_Cache[a][0] <<1;
						Display_Cache[a][1] = Display_Cache[a][1] <<1;
						Display_Cache[a][2] = Display_Cache[a][2] <<1;
						Display_Cache1[a][0] = Display_Cache1[a][0] <<1;
						Display_Cache1[a][1] = Display_Cache1[a][1] <<1;
						Display_Cache1[a][2] = Display_Cache1[a][2] <<1;
					}
					showLine(waitb[num]);  //8(5): 2.12 0.38
				}
		}

	#else
		//GPIO6_LOW;
		for(plane = 0; plane < scan; plane ++) //��ɨ�� ɨ��8��
		{
				u8 num,a;
			  for(a=0;a<32;a++){
					//ѭ����Ҫ 87.33 us
					u16 number;
					number = plane *32 + a;
				  Display_Cache[a][0]=Display_PWM[number][0];
				  Display_Cache[a][1]=Display_PWM[number][1];
				  Display_Cache[a][2]=Display_PWM[number][2];
				  Display_Cache[a+32][0]=Display_PWM[number+512][0];
				  Display_Cache[a+32][1]=Display_PWM[number+512][1];
				  Display_Cache[a+32][2]=Display_PWM[number+512][2];
					
				  Display_Cache1[a][0]=Display_PWM[number+256][0];
				  Display_Cache1[a][1]=Display_PWM[number+256][1];
				  Display_Cache1[a][2]=Display_PWM[number+256][2];
				  Display_Cache1[a+32][0]=Display_PWM[number+768][0];
				  Display_Cache1[a+32][1]=Display_PWM[number+768][1];
				  Display_Cache1[a+32][2]=Display_PWM[number+768][2];
				}
			  setRow(plane);  // ��ѡ��
			  for(num=8;num>0;num--) //ÿһ��ɨ��8��
			  {
						for(s = 0; s <2 /*= (MATRIX_WIDTH/32)*/; s ++) //ɨ2ģ�� 32*2 ����  0.126ms  136usɨ��һ��
						{
								for(a=0;a<MATRIX_MODULE;a++) //ѭ����0 ~ 32  ѭ����Ҫ68.25 us
								{
									  u16 aaa = s*32+a;
										if((Display_Cache[aaa][0] & 0x80) == 0x80)
											//MTX_PORTc->BSRR = MTX_PR0;
											SET_RGB_PIN_R1(1);
										else
											SET_RGB_PIN_R1(0);
											//MTX_PORTc->BRR  = MTX_PR0; 										
										if((Display_Cache[aaa][1] & 0x80) == 0x80)
											//MTX_PORT->BSRR = MTX_PG0;
											SET_RGB_PIN_G1(1);
										else
											//MTX_PORT->BRR  = MTX_PG0;
											SET_RGB_PIN_G1(0);
										if((Display_Cache[aaa][2] & 0x80) == 0x80)
											//MTX_PORTc->BSRR = MTX_PB0;
											SET_RGB_PIN_B1(1);
										else
											//MTX_PORTc->BRR  = MTX_PB0;
											SET_RGB_PIN_B1(0);

										if((Display_Cache1[aaa][0] & 0x80) == 0x80)
											//MTX_PORTc->BSRR = MTX_PR1;
											SET_RGB_PIN_R2(1);
										else
											//MTX_PORTc->BRR  = MTX_PR1; 
											SET_RGB_PIN_R2(0);
										if((Display_Cache1[aaa][1] & 0x80) == 0x80)
											//MTX_PORT->BSRR = MTX_PG1;
											SET_RGB_PIN_G2(1);
										else
											//MTX_PORT->BRR  = MTX_PG1;
											SET_RGB_PIN_G2(0);
										if((Display_Cache1[aaa][2] & 0x80) == 0x80)
											//MTX_PORTc->BSRR = MTX_PB1;
											SET_RGB_PIN_B2(1);
										else
											//MTX_PORTc->BRR  = MTX_PB1;
											SET_RGB_PIN_B2(0);
										CLK_TOGGLE;
								}
						}
						for(a=0;a<64;a++)
						{
							Display_Cache[a][0] = Display_Cache[a][0] <<1;
							Display_Cache[a][1] = Display_Cache[a][1] <<1;
							Display_Cache[a][2] = Display_Cache[a][2] <<1;
							Display_Cache1[a][0] = Display_Cache1[a][0] <<1;
							Display_Cache1[a][1] = Display_Cache1[a][1] <<1;
							Display_Cache1[a][2] = Display_Cache1[a][2] <<1;
						}
						showLine(waits[num]);  //8(5): 2.12 0.38
						//showLine(waitb[num]);
				}
		}
		//GPIO6_HIGH;
	#endif
}
/**
  * @brief  sets the row on the row gpio ports
  * @param  None
  * @retval None
  */
void setRow(u8 row) 
{
	// todo: perhaps a lookup table could give us a tiny boost here.

	if (row & 0x01) SET_RGB_PIN_A(1);//MTX_PORTc->BSRR = MTX_PA;
	else SET_RGB_PIN_A(0);//MTX_PORTc->BRR = MTX_PA;

	if (row & 0x02) SET_RGB_PIN_B(1);//MTX_PORTc->BSRR = MTX_PB;
	else SET_RGB_PIN_B(0);//MTX_PORTc->BRR = MTX_PB;

	if (row & 0x04) SET_RGB_PIN_C(1);//MTX_PORTc->BSRR = MTX_PC;
	else SET_RGB_PIN_C(0);//MTX_PORTc->BRR = MTX_PC;
}

#ifdef CODE_FOR_51
//***********16X32ͼƬ��ʾ����******************************************************/
void Picture16X32(char *str)
{
    //ģʽ1����ʱ
    uint8_t y,z,avl,x;
    for(y=16; y>0; y--) //д��16��     //01234567
    {
        for(z=0; z<8; z++) //������д��
        {
            avl=str[(y-1)*4+z];//Ѱ�ҵ���ģ
            for(x=0; x<8; x++)             //д��һ���е�8��
            {
                LED_X=31-x-z*8;
                LED_Y=y-1;
                if(avl&0x80)
                LED_dot_write(LED_X,LED_Y,2,1);    //��㵽X,Y,����ɫ��0��1��2�ƣ�,��/��,
                else
                LED_dot_write(LED_X,LED_Y,2,0);    //��㵽X,Y,����ɫ��0��1��2�ƣ�,��/��,
                avl<<=1;
            }
        }
    }
}
/*************************************************************

                   LED16X64˫ɫ������
*************************************************************/

//**************************************************************
/*******************************************
������������Ӻ�������
��  �ã�LED_dot_write(uchar x,uchar y,uchar colour,bit aa)
��  ������ģλ��/���ο���ɫ/�ڲ��Ƿ����0,1
����ֵ��
��  ����
��  ע��LEDup_dow=1���� LEDup_dow=0����
*******************************************/
void LED_dot_write(uint8_t x,uint8_t y,uint8_t colour,uint8_t aa)//��㵽X,Y,����ɫ��0��1��2�ƣ�,��/��,
{
    uint8_t dateR,dateG,bite;
    if((x<=(X_max-1))&&(y<=(Y_max-1)))                       //X,Y��λ
    {
        bite=0x80;                                           //������λ��
        switch(colour)
        {
        case 0:
            dateR=LED_RAM[(y*4)+x/8];
            break;             
        case 1:
            dateG=LED_RAM[(LED_byte/2)+(y*4)+x/8];
            break; 
        case 2:
            dateR=LED_RAM[(y*4)+x/8];
            dateG=LED_RAM[(LED_byte/2)+(y*4)+x/8];
            break;                 //������������������
        }
        bite=(bite|0x80)>>(x&0x07);//�ѵ�浽ȷ����������
        switch(colour)            //��ɫѡ��
        {
        case 0:
            if(!aa)
            {
                dateR|=bite;
            }
            else
            {
                dateR&=(~bite);
            }
            LED_RAM[(y*4)+x/8]=dateR;
            LED_RAM[(LED_byte/2)+(y*4)+x/8]|=bite;
            break;//��д���������
        case 1:
            if(!aa)
            {
                dateG|=bite;
            }
            else
            {
                dateG&=(~bite);
            }
            LED_RAM[(LED_byte/2)+(y*4)+x/8]=dateG;
            LED_RAM[(y*4)+x/8]|=bite;
            break;//��д������������
        case 2:
            if(!aa)
            {
                dateR|=bite;
            }
            else
            {
                dateR&=(~bite);
            }
            LED_RAM[(y*4)+x/8]=dateR;//��д��������������
            if(!aa)
            {
                dateG|=bite;
            }
            else
            {
                dateG&=(~bite);
            }
            LED_RAM[(LED_byte/2)+(y*4)+x/8]=dateG;
            break;
        }
    }
}
void Sao_Miao(void)
{   
	uint8_t i,m=0,z,dateR2,dateR,add;
	SET_RGB_PIN_R1(0);
	SET_RGB_PIN_G1(0);
	SET_RGB_PIN_B1(0);
	SET_RGB_PIN_R2(0);
	SET_RGB_PIN_G2(0);
	SET_RGB_PIN_B2(0);

    for(i=1; i<5; i++)                                   //ÿ��4�ֽ�
    {
  		                            
            add=(i+m*4);                                 //�����ַ
            dateR2=~LED_RAM[LED_byte-add];
			dateR=~LED_RAM[LED_byte-add-32];
            //dateSDA_R=~LED_RAM[LED_byte-((LED_byte>>1)+add)]; 
	        for(z=0; z<8; z++)                          //�ͳ���λ����
	        {   
				(*SDA_RGB1)(dateR2&0X80); //���Ͷ�Ӧ R G B�ź� �°���	����
				(*SDA_RGB)(dateR&0X80); //���Ͷ�Ӧ R G B�ź� �ϰ���	����
	   
	            SHCP=0;  //��ʱ���ź�
	            dateR2<<=1;
	            dateR<<=1;
	            SHCP=1;
	        }
    }
    /******************��������*********************/
    STCP=1;    STCP=0;        //�����������ʾһ��

    scan(7-m);
    if(++m>7)
     m=0;    //��ɨ�����

}
#endif
void drawPixel(s8 x, s8 y, u32 Color)
{
	s8 hwx,hwy;
  //if(Color>0x00ffffff)return ;
	// check for out of bounds coordinates     
	if(x < 0 || y < 0 ||(x>(MATRIX_MODULE-1)) || (y>(MATRIX_MODULE-1)))return ;
	// map pixel into hardware buffer before writing
	if (rotation_Degrees == rotation0) {
		hwx = x;
    hwy = y;
	} else if (rotation_Degrees == rotation180) {
		hwx = (32 - 1) - x;
		hwy = (32 - 1) - y;
	} else if (rotation_Degrees == rotation90) {
		hwx = (32 - 1) - y;
		hwy = x;
	} else { /* if (screenConfig.rotation == rotation270)*/
		hwx = y;
		hwy = (32 - 1) - x;
	}
	Display_PWM[hwy*32+hwx][2] |= Color;
	Display_PWM[hwy*32+hwx][1] |= Color>>8;
	Display_PWM[hwy*32+hwx][0] |= Color>>16;

  if(Color==0x00){
		Display_PWM[hwy*32+hwx][2] = 0x00;
		Display_PWM[hwy*32+hwx][1] = 0x00;
		Display_PWM[hwy*32+hwx][0] = 0x00;
	};
}
void show_Image(const u8 *image)
{
		u8 i, j;
		for(j=0;j<32;j++){
			for(i=0;i<32;i++){
				//drawPixel(i,j,Color888(IMAGE[j*32+i],IMAGE[j*32+i+1],IMAGE[j*32+i+2]));
			drawPixel(i,j,((u32)image[j*32+i] << 16) | ((u32)image[j*32+i+1]<<8) | ((u32)image[j*32+i+2]));}
		}
}
void drawImage(u8 x, u8 y, u32 Color, const u8 *addres)
{
	u8 b,c,d;
	//a = a / 8;

	for(b = 0;b < addres[1];b++){
		for(d = 0;d < addres[0]/8; d++){
			u8 num = addres[b*(addres[0]/8)+d+2];
			for(c = 0; c < 8; c++){
				if((num & 0x80) == 0x80)
					drawPixel(d*8+c+x,b+y,Color);
				num=num<<1;
				//if(num & (1<<c))
				//	drawPixel(c+x,b+y,Color);
			}
		}
	}
}
void ClearBuff(u16 num1, u16 num2)
{
	num2++;
  for(;num1<num2;num1++)
	{
		Display_PWM[num1][0]=0x00;
		Display_PWM[num1][1]=0x00;
		Display_PWM[num1][2]=0x00;
	}
}
// Draw a circle outline
void drawCircle(s8 x0, s8 y0, s8 r, u32 color) 
{
  s8 f = 1 - r;
  s8 ddF_x = 1;
  s8 ddF_y = -2 * r;
  s8 x = 0;
  s8 y = r;

  drawPixel(x0  , y0+r, color);
  drawPixel(x0  , y0-r, color);
  drawPixel(x0+r, y0  , color);
  drawPixel(x0-r, y0  , color);

  while (x<y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    drawPixel(x0 + x, y0 + y, color);
    drawPixel(x0 - x, y0 + y, color);
    drawPixel(x0 + x, y0 - y, color);
    drawPixel(x0 - x, y0 - y, color);
    drawPixel(x0 + y, y0 + x, color);
    drawPixel(x0 - y, y0 + x, color);
    drawPixel(x0 + y, y0 - x, color);
    drawPixel(x0 - y, y0 - x, color);
  } 

//	drawLine(x0 + r/2,y0 + r, x0+r,y0+r/2, color);//A ->> B
//	drawLine(x0 + r,y0 + r/2, x0 + r,y0 - r/2, color);	//B ->> C
//	drawLine(x0 + r,y0 - r/2, x0 + r/2,y0 - r, color);//C ->> D 
//	drawLine(x0 + r/2,y0 - r, x0 - r/2,y0 - r, color);//D ->> E
//	drawLine(x0 - r/2,y0 - r, x0 - r,y0 - r/2, color);//E ->> F
//	drawLine(x0 - r,y0 - r/2, x0 - r,y0 + r/2, color);//F ->> G
//	drawLine(x0 - r,y0 + r/2, x0 - r/2,y0 + r, color);//G ->> H
//	drawLine(x0 - r/2,y0 + r, x0 + r/2,y0 + r, color);//H ->> A
}
void DrawOval(s8 x0, s8 y0, s8 r1, s8 r2,u32 color)
{	
	//��һ���۾�
	drawLine( 7,0, 4,3, color);//A ->> B
	drawLine(7,0, 10,3, color);//A ->> B
	
	drawLine( 3,4,3,11,  color);//A ->> B
	drawLine(11,4,11,11,  color);//A ->> B
	
	drawLine( 4,12,7,15,  color);//A ->> B
	drawLine(10,12,7,15,  color);//A ->> B
	
	drawPixel(5, 7, color);
	drawPixel(9, 7, color);
	drawLine(5,8,7,10,  color);//A ->> B
	drawLine(9,8,7,10,  color);//A ->> B
	//�ڶ����۾�
	drawLine( 7+17,0, 4+17,3, color);//A ->> B
	drawLine(7+17,0, 10+17,3, color);//A ->> B
	
	drawLine(3+17,4,3+17,11,  color);//A ->> B
	drawLine(11+17,4,11+17,11,  color);//A ->> B
	
	drawLine( 4+17,12,7+17,15,  color);//A ->> B
	drawLine(10+17,12,7+17,15,  color);//A ->> B
	
	drawPixel(5+17, 7, color);
	drawPixel(9+17, 7, color);
	drawLine(5+17,8,7+17,10,  color);//A ->> B
	drawLine(9+17,8,7+17,10,  color);//A ->> B

}
//draw heart
void draw_heart_blank(u32 color)
{
	s8 x1= 7;
	s8 y1= 2;
	s8 x2=1;
	s8 y2=8;
	s8 x3=1;
	s8 y3=9;
	s8 x4=4;
	s8 y4=12;
	s8 x5= 5;
	s8 y5=12;
	s8 x6=7;
	s8 y6=10;
	s8 x7=9;
	s8 y7=12;
	s8 x8=10;
	s8 y8=12;
	s8 x9=13;
	s8 y9=9;
	s8 x10=13;
	s8 y10 =8;
	s8 offset =17;
	
			//��һ����
	drawLine( x1,y1, x2,y2, color);//A ->> B
	drawLine(x2,y2, x3,y3, color);//A ->> B
	
	drawLine( x3,y3,x4,y4,  color);//A ->> B
	drawLine(x4,y4,x5,y5,  color);//A ->> B
	drawLine(x5,y5,x6,y6,  color);//A ->> B
	drawLine( x6,y6,x7,y7,  color);//A ->> B
	drawLine(x7,y7,x8,y8,  color);//A ->> B
	drawLine( x8,y8,x9,y9,  color);//A ->> B
	drawLine( x9,y9,x10,y10,  color);//A ->> B
	drawLine(x10,y10,x1,y1,  color);//A ->> B

	
	//�ڶ�����
	drawLine( x1+offset,y1, x2+offset,y2, color);//A ->> B
	drawLine(x2+offset,y2, x3+offset,y3, color);//A ->> B
	
	drawLine( x3+offset,y3,x4+offset,y4,  color);//A ->> B
	drawLine(x4+offset,y4,x5+offset,y5,  color);//A ->> B
	drawLine(x5+offset,y5,x6+offset,y6,  color);//A ->> B
	drawLine( x6+offset,y6,x7+offset,y7,  color);//A ->> B
	drawLine(x7+offset,y7,x8+offset,y8,  color);//A ->> B
	drawLine( x8+offset,y8,x9+offset,y9,  color);//A ->> B
	drawLine( x9+offset,y9,x10+offset,y10,  color);//A ->> B
	drawLine(x10+offset,y10,x1+offset,y1,  color);//A ->> B
}
//draw heart
void draw_heart_full(u32 color)
{
	s8 x1= 1;
	s8 y1= 8;
	s8 x2=1;
	s8 y2=9;
	
	s8 x3=2;
	s8 y3=7;
	s8 x4=2;
	s8 y4=10;
	
	s8 x5= 3;
	s8 y5=11;
	s8 x6=3;
	s8 y6=6;
	
	s8 x7=4;
	s8 y7=12;
	s8 x8=4;
	s8 y8=5;
	
	s8 x9=5;
	s8 y9=4;
	s8 x10=5;
	s8 y10 =12;
	
	s8 x11=6;
	s8 y11=3;
	s8 x12=6;
	s8 y12 =11;
	
	s8 x13=7;
	s8 y13=2;
	s8 x14=7;
	s8 y14 =9;
	
	s8 offset =17;
	
	
			//��һ����
	drawLine( x1,y1, x2,y2, color);//A ->> B
	drawLine( x3,y3,x4,y4,  color);//A ->> B
	drawLine(x5,y5,x6,y6,  color);//A ->> B
	drawLine(x7,y7,x8,y8,  color);//A ->> B
	drawLine( x9,y9,x10,y10,  color);//A ->> B
	drawLine( x11,y11,x12,y12,  color);//A ->> B
	
	drawLine( x13,y13,x14,y14,  color);//A ->> B
	
	drawLine( x1+12,y1, x2+12,y2, color);//A ->> B
	drawLine( x6+10,y3,x4+10,y4,  color);//A ->> B
	drawLine(x5+8,y5,x6+8,y6,  color);//A ->> B
	drawLine(x7+6,y7,x8+6,y8,  color);//A ->> B
	drawLine( x9+4,y9,x10+4,y10,  color);//A ->> B
	drawLine( x11+2,y11,x12+2,y12,  color);//A ->> B
	
	//�ڶ�����
	drawLine( x1+offset,y1, x2+offset,y2, color);//A ->> B
	drawLine( x3+offset,y3,x4+offset,y4,  color);//A ->> B
	drawLine(x5+offset,y5,x6+offset,y6,  color);//A ->> B
	drawLine(x7+offset,y7,x8+offset,y8,  color);//A ->> B
	drawLine( x9+offset,y9,x10+offset,y10,  color);//A ->> B
	drawLine( x11+offset,y11,x12+offset,y12,  color);//A ->> B
	
	drawLine( x13+offset,y13,x14+offset,y14,  color);//A ->> B
	
	drawLine( x1+12+offset,y1, x2+12+offset,y2, color);//A ->> B
	drawLine( x3+10+offset,y3,x4+10+offset,y4,  color);//A ->> B
	drawLine(x5+8+offset,y5,x6+8+offset,y6,  color);//A ->> B
	drawLine(x7+6+offset,y7,x8+6+offset,y8,  color);//A ->> B
	drawLine( x9+4+offset,y9,x10+4+offset,y10,  color);//A ->> B
	drawLine( x11+2+offset,y11,x12+2+offset,y12,  color);//A ->> B
}
// Bresenham's algorithm - thx wikpedia
void drawLine(s8 x0, s8 y0, s8 x1, s8 y1, u32 Color) {
  s8 steep = _abs(y1 - y0) > _abs(x1 - x0);
  s8 ystep, err, dx, dy;

	if (steep) {
    _swap_int8_t(x0, y0);
    _swap_int8_t(x1, y1);
  }

  if (x0 > x1) {
    _swap_int8_t(x0, x1);
    _swap_int8_t(y0, y1);
  }

  dx = x1 - x0;
  dy = _abs(y1 - y0);

  err = dx / 2;

  if (y0 < y1) {
    ystep = 1;
  } else {
    ystep = -1;
  }

  for (; x0<=x1; x0++) {
    if (steep) {
      drawPixel(y0, x0, Color);
    } else {
      drawPixel(x0, y0, Color);
    }
    err -= dy;
    if (err < 0) {
      y0 += ystep;
      err += dx;
    }
  }
}
void drawFastVLine(s8 x, s8 y, s8 h, u32 Color) {
  // Update in subclasses if desired!
  drawLine(x, y, x, y+h-1, Color);
}

void drawFastHLine(s8 x, s8 y, s8 w, u32 Color)
{
  // Update in subclasses if desired!
  drawLine(x, y, x+w-1, y, Color);
}
// Draw a rectangle
void drawRect(s8 x, s8 y, s8 w, s8 h, u32 Color) {
  drawFastHLine(x, y, w, Color);
  drawFastHLine(x, y+h-1, w, Color);
  drawFastVLine(x, y, h, Color);
  drawFastVLine(x+w-1, y, h, Color);
}

void fillRect(s8 x, s8 y, s8 w, s8 h,u32 Color) {
  // Update in subclasses if desired!
  s8 i;
	for (i=x; i<x+w; i++) {
    drawFastVLine(i, y, h, Color);
  }
}
// Draw a triangle
void drawTriangle(s8 x0, s8 y0, s8 x1, s8 y1, s8 x2, s8 y2, u32 Color) {
  drawLine(x0, y0, x1, y1, Color);
  drawLine(x1, y1, x2, y2, Color);
  drawLine(x2, y2, x0, y0, Color);
}

void drawCircleHelper( s8 x0, s8 y0, s8 r, s8 cornername, u32 Color) {
  s8 f     = 1 - r;
  s8 ddF_x = 1;
  s8 ddF_y = -2 * r;
  s8 x     = 0;
  s8 y     = r;

  while (x<y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f     += ddF_y;
    }
    x++;
    ddF_x += 2;
    f     += ddF_x;
    if (cornername & 0x4) {
      drawPixel(x0 + x, y0 + y, Color);
      drawPixel(x0 + y, y0 + x, Color);
    }
    if (cornername & 0x2) {
      drawPixel(x0 + x, y0 - y, Color);
      drawPixel(x0 + y, y0 - x, Color);
    }
    if (cornername & 0x8) {
      drawPixel(x0 - y, y0 + x, Color);
      drawPixel(x0 - x, y0 + y, Color);
    }
    if (cornername & 0x1) {
      drawPixel(x0 - y, y0 - x, Color);
      drawPixel(x0 - x, y0 - y, Color);
    }
  }
}

// Used to do circles and roundrects
void fillCircleHelper(s8 x0, s8 y0, s8 r, s8 cornername, s8 delta, u32 Color) {

  s8 f     = 1 - r;
  s8 ddF_x = 1;
  s8 ddF_y = -2 * r;
  s8 x     = 0;
  s8 y     = r;

  while (x<y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f     += ddF_y;
    }
    x++;
    ddF_x += 2;
    f     += ddF_x;

    if (cornername & 0x1) {
      drawFastVLine(x0+x, y0-y, 2*y+1+delta, Color);
      drawFastVLine(x0+y, y0-x, 2*x+1+delta, Color);
    }
    if (cornername & 0x2) {
      drawFastVLine(x0-x, y0-y, 2*y+1+delta, Color);
      drawFastVLine(x0-y, y0-x, 2*x+1+delta, Color);
    }
  }
}

void fillCircle(s8 x0, s8 y0, s8 r, u32 Color) 
{
  drawFastVLine(x0, y0-r, 2*r+1, Color);
  fillCircleHelper(x0, y0, r, 3, 0, Color);
}
// Fill a triangle
void fillTriangle(s8 x0, s8 y0, s8 x1, s8 y1, s8 x2, s8 y2, u32 Color) 
{

  int16_t a, b;
//  int16_t
//    dx01 = x1 - x0,
//    dy01 = y1 - y0,
//    dx02 = x2 - x0,
//    dy02 = y2 - y0,
//    dx12 = x2 - x1,
//    dy12 = y2 - y1;
//  int32_t
//    sa   = 0,
//    sb   = 0;

  // Sort coordinates by Y order (y2 >= y1 >= y0)
  if (y0 > y1) {
    _swap_int8_t(y0, y1); _swap_int8_t(x0, x1);
  }
  if (y1 > y2) {
    _swap_int8_t(y2, y1); _swap_int8_t(x2, x1);
  }
  if (y0 > y1) {
    _swap_int8_t(y0, y1); _swap_int8_t(x0, x1);
  }

  if(y0 == y2) { // Handle awkward all-on-same-line case as its own thing
    a = b = x0;
    if(x1 < a)      a = x1;
    else if(x1 > b) b = x1;
    if(x2 < a)      a = x2;
    else if(x2 > b) b = x2;
    drawFastHLine(a, y0, b-a+1, Color);
    return;
  }
}
void love(void)
{
		#define A 1
    double x,y;
	  u8 x1,y1;
    printf("���ĺ���");
    for(y=-4;y<=0;y+=0.3)
    {
			for(x=-2;x<=4;x+=0.2)
				if(fabs(sqrt(x*x+y*y)-A*sin(2*atan(y/x)))<=1 ||fabs(sqrt(x*x+y*y)-A*sin(2*atan(-y/x)))<=1){
					drawPixel(x1,y1,0x00ff);
				  x1++;
					printf("*");
				}
				else{
					printf(" ");
				  drawPixel(x1,y1,0x00);
					x1++;
				}
			printf("\n");
			y1++;
			x1=0;
    }
    for(y=-1;y<=0;y+=0.2)
    {
			for(x=-2;x<=4;x+=0.2)
				if(fabs(y)-0.65*x*x>=0.2){
					drawPixel(x1,y1,0x00ff);
					x1++;
					printf("*");
				}
				else {
					printf(" ");
				  drawPixel(x1,y1,0x00);
					x1++;
				}
				printf("\n");
				y1++;
				x1=0;
    }
}
void lcd_draw_image(const unsigned char *pic)
 {
 	//const unsigned char *p = pic ;
	u32 x, y;

	for (y=0; y<32; y++)     
	{
		for (x=0; x<64; x++)     
		{
			bufferA[(64*y+x)] = (gImage_image[(64*y+x)*3]<<16) + (gImage_image[(64*y+x)*3+1]<<8) + (gImage_image[(64*y+x)*3+2]);
		}
	}

}
void Eyes_Change(u8 tim,u8 flag)
{
	if(flag == BLUE_EYES)
		switch ( tim  )
				{
					case 0 :
						drawPixel(8, 8, COLOR_GREEN);
						drawPixel(24, 8, COLOR_GREEN);
						break;
					case 1 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_GREEN,Imagelove[2]);
						drawImage(16,0,COLOR_GREEN,Imagelove[2]);
						break;
					case 2 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_GREEN,Imagelove[1]);
						drawImage(16,0,COLOR_GREEN,Imagelove[1]);
						break;
					case 3 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_GREEN,Imagelove[0]);
						drawImage(16,0,COLOR_GREEN,Imagelove[0]);
						break;
					case 4 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_GREEN,Imagelove[1]);
						drawImage(16,0,COLOR_GREEN,Imagelove[1]);
						break;
					case 5 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_GREEN,Imagelove[2]);
						drawImage(16,0,COLOR_GREEN,Imagelove[2]);
						break;
					case 6 :
						
						drawPixel(8, 8, COLOR_GREEN);
						drawPixel(24, 8, COLOR_GREEN);
						ClearBuff(0,16*32);
						break;
					default:
					   break;
				}
	else if(flag == RED_EYES)
		switch ( tim  )
				{
					case 0 :
						drawPixel(8, 8, COLOR_RED);
						drawPixel(24, 8, COLOR_RED);
						break;
					case 1 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_RED,Imagelove[2]);
						drawImage(16,0,COLOR_RED,Imagelove[2]);
						break;
					case 2 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_RED,Imagelove[1]);
						drawImage(16,0,COLOR_RED,Imagelove[1]);
						break;
					case 3 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_RED,Imagelove[0]);
						drawImage(16,0,COLOR_RED,Imagelove[0]);
						break;
					case 4 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_RED,Imagelove[1]);
						drawImage(16,0,COLOR_RED,Imagelove[1]);
						break;
					case 5 :
						ClearBuff(0,16*32);
						drawImage(0,0,COLOR_RED,Imagelove[2]);
						drawImage(16,0,COLOR_RED,Imagelove[2]);
						break;
					case 6 :
						
						drawPixel(8, 8, COLOR_RED);
						drawPixel(24, 8, COLOR_RED);
						ClearBuff(0,16*32);
						break;
					default:
					   break;
				}


} 

