#ifndef __MOTOR_CONTROL_H
#define __MOTOR_CONTROL_H
#include "sys_config.h"
#include "can.h"
#include "bms.h"
typedef enum{
	MOTOR_CTL_MSGID_CMD 			= 0X01,
	UPLOAD_STATUS_AND_CURRENT       = 0X02,	
	UPLOAD_ENCODER_AND_VELOCITY     = 0X03,	
	BATTARY_MONITOR_MSGID_CMD 		= 0X04,
	RESET_STATUS_MSGID_CMD	 		= 0X05,
	ENCODER_RESET_CMD	  			= 0X06,
	OPEN_YUNTAI_CMD	  				= 0X07,
	ALARM_CMD	  					= 0X08,
    ENABLE_CHARGE_CMD	  		    = 0X09,
    INFRARED_DISTANCE_CMD           = 0X0A,
	ERROR_STATUS_CMD	  			= 0XFF,
}CMD;
typedef enum{
		NO_ERROR =0x00,
		SPEEDOUT_ERROR = 0x01,
		BATTERY_ERROR =0x02
}etERROR;
typedef struct{
 u32 encoder_left ;
 u32 encoder_right ;
 u32 velocity_left ;
 u32 velocity_right;
 u16 current_left;
 u16 current_right;
 u16 status_w_left;
 u16 status_w_right;
}MOTORMSG;

#define HEARTBEATTIME 50 //与PC机保持连接最大超时时间，单位2ms

#define MOTOR_SPEED_PS2_TURN    3   //PS2遥控手柄控制转向电机转速                   3rps
#define MOTOR_SPEED_PS2_LEVEL1  6   //PS2遥控手柄控制直行电机转速档位1                6rps
#define MOTOR_SPEED_PS2_LEVEL2  12  //PS2遥控手柄控制直行电机转速档位2                12rps

#define REDUCTION_RATIO     28  //电机减速比
#define SPEED_COEFFICIENT   240 //电机速度系数，鸣志电机系统自带属性，速度指令需要和其做积
#define delay_n 5   //设置canopen电机参数是命令最少间隔时间单位ms

extern u8 encoder_valueleft[4];
extern u8 encoder_valueright[4];
extern u8 velocity_valueleft[4],velocity_valueright[4];
extern u8 current_valueleft[2],current_valueright[2];
extern u8 errcode[3];
extern u8 status_word_left[2];
extern u8 status_word_right[2];
extern u8 startcmdstatus;
extern Message Can_Msg_SYNCMY;//SYNC 同步报文
extern u8 length;
extern u8 sequence;


void SetCanopenParameter(u8 id);
void SetMotorTargetVelocity(s32 vel_left,s32 vel_right);
void MotorInit(void);
void MotionHalts(void);
void StartMotion(void);
u8 Set_Speed(float leftvalue,float rightvalue);
void Turn_Left(void);
void Turn_Right(void);
void Move_Forward(u8 level);
void Back_Off(u8 level);
void Date_Up_Load(u8 msgid);
void Motion_Status(void);
void StatusWordAnalysis(void);
void AnalysisMessagefromDriver(void);
u8 AbnormalReporting(u8 type,u8 group,u8 number);
void AnalysisMessagefromDriver(void);
void GetValCurrent(u8 idnode);
void GetValEncoder(u8 idnode);
void GetValStatus(u8 idnode);
void GetValVelocity(u8 idnode);
void Mode_CTL_TO_PC(void);
void Mode_CTL_TO_PS2(void);


unsigned short GetCRC16(unsigned char *ptr,unsigned char len);

#endif

