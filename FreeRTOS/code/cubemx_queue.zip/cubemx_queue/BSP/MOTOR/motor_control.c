/***********************************************************************************
 * 文 件 名   : motor_control.c
 * 负 责 人   : jishubao
 * 创建日期   : 2019年4月11日
 * 文件描述   : 电机驱动函数源文件
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 20190411 by jishubao, 修改电机加速度&减速度为 30m/(s*s)
***********************************************************************************/

#include "motor_control.h"
#include "sys_config.h"
#include "CANOpenObjDictConfig.h"
#include "gpio.h"
#include "ps2.h"
#include "delay.h"
#include "bsp_usart.h"
#include "usart.h"
#include "bsp_gpio.h"
#include "bsp_can.h" 
#include "motor_control.h" 
#include "stdlib.h"
#include "string.h"


Message Can_Msg_ReadSwitch_NO[2];
Message Can_Msg_SwitchOn_NO[2];
Message Can_Msg_OperationEn_NO[2];
Message Can_Msg_VelocityMode_NO[2];
Message Can_Msg_TargetVelocity_NO[2];
Message Can_Msg_SetAcc_NO[2];
Message Can_Msg_SetDec_NO[2];
Message Can_Msg_MotionStart_NO[2];
Message Can_Msg_MotionHalts_NO[2];
Message Can_Msg_DSPclearAlarm_NO[2];

/* 设置驱动器通讯参数Message */
Message Can_Msg_TPDOTRANTYPE_NO[2][2];
Message Can_Msg_ChangeMotionStatusToOperation[2];
Message Can_Msg_ChangeMotionStatusToPreOperation[2];

/* 设置驱动器映射参数Message */
Message Can_Msg_Turn_Off_TPDOX[2][2];
Message Can_Msg_Set_Number_Mapped_objectsTo0[2][2];
Message Can_Msg_Map_Actual_value_to_TPDOX_objectX[2][4];
Message Can_Msg_Set_Number_Mapped_objectsTo2[2][2];
Message Can_Msg_Turn_On_TPDOX[2][2];

//SYNC报文
Message Can_Msg_SYNCMY;

/* 位置、速度、电流，状态 参数 */
Message Can_Msg_ActPosition_NO[2];
Message Can_Msg_ActVelocity_NO[2];
Message Can_Msg_ActCurrent_NO[2];
Message Can_Msg_MotionStatus_NO[2];
  
 
 //驱动器TPDO通讯参数设置
 UNS8 data_cmd_ChangeTPDOTransType180x[2][8]  = {
    {0x2F,0x01,0x18,0x02,0x01,0x00,0x00,0x00},  //ChangeTPDOTransType1801  TPDO2
    {0x2F,0x02,0x18,0x02,0x02,0x00,0x00,0x00}   //ChangeTPDOTransType1802  TPDO3
}; 
 //驱动器节点状态切换为运行状态
 UNS8 data_cmd_ChangeMotionStatusToOperation[2][2] = {
    {0x01,0x01},//将节点1状态切换到运行状态cmd+NodeID
    {0x01,0x02}//将节点2状态切换到运行状态cmd+NodeID
};
 //驱动器节点状态切换为预运行状态
 UNS8 data_cmd_ChangeMotionStatusToPreOperation[2][2] = {
    {0x80,0x01},//将节点1状态切换到运行状态cmd+NodeID
    {0x80,0x02}//将节点2状态切换到运行状态cmd+NodeID
};
 
 //驱动器TPDO映射参数设置
 UNS8 data_cmd_Turn_Off_TPDOX[2][8] = {
    {0x23,0x01,0x18,0x01,0x80,0x02,0x00,0x80},//关闭TPDO1
    {0x23,0x02,0x18,0x01,0x80,0x03,0x00,0x80}//关闭TPDO2
 };
 UNS8 data_cmd_Set_Number_Mapped_objectsTo0[2][8] = {
    {0x2F,0x01,0x1A,0x00,0x00,0x00,0x00,0x00},//设置0X1A01映射对象个数为0
    {0x2F,0x02,0x1A,0x00,0x00,0x00,0x00,0x00}//设置0X1A02映射对象个数为0
 };
 UNS8 data_cmd_Map_Actual_value_to_TPDOX_objectX[4][8] = {
    {0x23,0x01,0x1A,0x01,0x20,0x00,0x0A,0x70},//设置编码器值映射到TPDO1的子索引01  4Bytes
    {0x23,0x01,0x1A,0x02,0x10,0x00,0x09,0x70},//设置速度值映射到TPDO1的子索引02                2Bytes
    {0x23,0x02,0x1A,0x01,0x10,0x00,0x41,0x60},//设置状态字映射到TPDO2的子索引01                2Bytes
    {0x23,0x02,0x1A,0x02,0x10,0x00,0x78,0x60}//设置电流值映射到TPDO2的子索引02                 2Bytes
 };
 UNS8 data_cmd_Set_Number_Mapped_objectsTo2[2][8] = {
    {0x2F,0x01,0x1A,0x00,0x02,0x00,0x00,0x00},//设置0X1A01映射对象个数为2
    {0x2F,0x02,0x1A,0x00,0x02,0x00,0x00,0x00}//设置0X1A02映射对象个数为2
 };
 UNS8 data_cmd_Turn_On_TPDOX[2][8] = {
    {0x23,0x01,0x18,0x01,0x80,0x02,0x00,0x00},//打开TPDO1
    {0x23,0x02,0x18,0x01,0x80,0x03,0x00,0x00}//打开TPDO2
 };
 
 //运行数据报文
 UNS8 data_cmd_ReadSwitch[]      = {0x2B,0x40,0x60,0x00,0x06,0x00,0x00,0x00};   //Ready to Switch on
 UNS8 data_cmd_SwitchOn[]        = {0x2B,0x40,0x60,0x00,0x07,0x00,0x00,0x00};   //Switched on
 UNS8 data_cmd_OperationEn[]     = {0x2B,0x40,0x60,0x00,0x0F,0x01,0x00,0x00};    //Operation Enabled; Motion Halted
 UNS8 data_cmd_VelocityMode[]    = {0x2F,0x60,0x60,0x00,0x03,0x00,0x00,0x00};    //Set to Profile Velocity Mode
 UNS8 data_cmd_TargetVelocity[]  = {0x23,0xFF,0x60,0x00,0x00,0x00,0x00,0x00};    // Set Target Velocity to 10 rps
 //UNS8 data_cmd_SetAcc[]          = {0x23,0x83,0x60,0x00,0x58,0x02,0x00,0x00};    //Set Acceleration to 100 rps/s
 //UNS8 data_cmd_SetDec[]          = {0x23,0x84,0x60,0x00,0x58,0x02,0x00,0x00};    //Set Deceleration to 100 rps/s
 //UNS8 data_cmd_SetAcc[]          = {0x23,0x83,0x60,0x00,0x2C,0x01,0x00,0x00};    //Set Acceleration to 50 rps/s
 //UNS8 data_cmd_SetDec[]          = {0x23,0x84,0x60,0x00,0x2C,0x01,0x00,0x00};    //Set Deceleration to 50 rps/s
 //UNS8 data_cmd_SetAcc[]          = {0x23,0x83,0x60,0x00,0xA4,0x01,0x00,0x00};    //Set Acceleration to 70 rps/s
 //UNS8 data_cmd_SetDec[]          = {0x23,0x84,0x60,0x00,0xA4,0x01,0x00,0x00};    //Set Deceleration to 70 rps/s
 UNS8 data_cmd_SetAcc[]          = {0x23,0x83,0x60,0x00,0xB4,0x00,0x00,0x00};    //Set Acceleration to 30 rps/s
 UNS8 data_cmd_SetDec[]          = {0x23,0x84,0x60,0x00,0xB4,0x00,0x00,0x00};    //Set Deceleration to 30 rps/s

 UNS8 data_cmd_MotionStart[]     = {0x2B,0x40,0x60,0x00,0x0F,0x00,0x00,0x00};   //Motion Starts
 //UNS8 data_cmd_MotionHalts[]     = {0x2B,0x40,0x60,0x00,0x0F,0x01,0x00,0x00};   //Motion Halts 
 UNS8 data_cmd_MotionHalts[]     = {0x23,0xFF,0x60,0x00,0x00,0x00,0x00,0x00};;   //Motion Halts set velocity to 0
 
 UNS8 data_cmd_GetPosition[]     = {0x43,0x0A,0x70,0x00,0x00,0x00,0x00,0x00};   //Request encoder value
 UNS8 data_cmd_GetVelActVal[]    = {0x4B,0x09,0x70,0x00,0x00,0x00,0x00,0x00};   //Request velocity_actual_value; The value reading from driver should be divided 240 to change to rps unit.
 UNS8 data_cmd_GetCurActValue[]  = {0x4B,0x78,0x60,0x00,0x00,0x00,0x00,0x00};  //current_actual_value;This object is only available on servo/step-servo drivers.The unit of this object is 0.01Amps
 UNS8 data_cmd_MotionStatus[]    = {0x4B,0x41,0x60,0x00,0x00,0x00,0x00,0x00};  //Motion_Status
 UNS8 data_cmd_DSPclearAlarm[]   = {0x2F,0x06,0x70,0x00,0x01,0x00,0x00,0x00};  //clear alarm of the drive
 
 UNS16 id_motor_no[2] ={0x0601,0x0602};//电机ID
 UNS8 len = 0x08;                       //报文数据长度
 UNS8 rtr_my =0x00;                     //数据类型
 
 u8 encoder_valueleft[4] = {0};
 u8 encoder_valueright[4] = {0};
 u8 velocity_valueleft[4] = {0};
 u8 velocity_valueright[4] = {0};
 u8 current_valueleft[2] =  {0};
 u8 current_valueright[2] =  {0};
 u8 status_word_left[2] =  {0};
 u8 status_word_right[2] =  {0};
 u8 stopflag=0;
 u8 startcmdstatus = 0;

 u32 encoder_left = 0;
 u32 encoder_right = 0;
 u32 velocity_left = 0;
 u32 velocity_right = 0;
 u16 current_left = 0;
 u16 current_right = 0;
 u16 status_w_left = 0;
 u16 status_w_right = 0;
 MOTORMSG motormsg;
 u8 errcode[3]={0};
 u8 length=0;
 u8 sequence=0;
 u8 ConfigError[3];
 

 /*****************************************************************************
  * 函 数 名  : SetMotorPar
  * 负 责 人  : jishubao
  * 创建日期  : 2018年11月19日
  * 函数功能  : 发送驱动器参数至驱动器函数
  * 输入参数  : Message * canmsg  驱动器参数结构体指针
  * 输出参数  : 无
  * 返 回 值  : 
  * 调用关系  : 
  * 其    它  : 
 
 *****************************************************************************/
 void SetMotorPar(Message * canmsg)
 {
     u8 countsend = 0;
     do
     {
         canSend(&hcan1,canmsg);  //发送命令
         delay_ms(delay_n);
         countsend++;
         if(countsend >= 3)//确保上电时参数发送成功，连续发3次
         {
             errcode[0] = 0x01;
             errcode[1] = canmsg->data[2];
             errcode[2] = canmsg->data[3];
             Date_Up_Load(0xff);
             startcmdstatus = 0;
         }
     }while(startcmdstatus);
 
 }
 /*****************************************************************************
  * 函 数 名  : MotorInit
  * 负 责 人  : jishubao
  * 创建日期  : 2018年11月19日
  * 函数功能  : 电机CANopen网络软件初始化
  * 输入参数  : void  无
  * 输出参数  : 无
  * 返 回 值  : void
  * 调用关系  : 
  * 其    它  : 
 
 *****************************************************************************/
  void MotorInit(void)
 {
     u8 i;
     /* 确保在运行状态意外停止导致驱动器报错 分为三步 */

     /* 步骤1：确保驱动器处于预操作重新设置驱动器状态为预操作状态 */  
     SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[0]);
     SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[1]);
     SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[0]);
     SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[1]);
     delay_ms(1500);
     /* 步骤2：清除由于运动状态下急停电机故障状态 */
     SetMotorPar(&Can_Msg_DSPclearAlarm_NO[0]);  //清除NODE1电机DSP故障，该指令需要在预操作状态下
     SetMotorPar(&Can_Msg_DSPclearAlarm_NO[1]);  //清除NODE2电机DSP故障，该指令需要在预操作状态下
     /*步骤3： 设置为运行状态 */
     SetMotorPar(&Can_Msg_OperationEn_NO[0]);
     SetMotorPar(&Can_Msg_OperationEn_NO[1]);
     delay_ms(500);

     /* 重新设置驱动器状态为预操作状态 */
     SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[0]);
     SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[1]);

     for(i=0;i<2;i++)
     {
         SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[i]);//设置为预操作状态       
         SetMotorPar(&Can_Msg_ReadSwitch_NO[i]);    
         SetMotorPar(&Can_Msg_SwitchOn_NO[i]);
     
         SetMotorPar(&Can_Msg_TPDOTRANTYPE_NO[i][0]);//设置TPDO2传输类型
         SetMotorPar(&Can_Msg_TPDOTRANTYPE_NO[i][1]);//设置TPDO3传输类型

         /* 映射设置分为6步 */
         
         /* 第1步  ：在预操作模式下   */
         SetMotorPar(&Can_Msg_ChangeMotionStatusToPreOperation[i]); //设置为预操作状态           

         /* 第2步  ：关闭TPDO   */
         SetMotorPar(&Can_Msg_Turn_Off_TPDOX[i][0]); //关闭TPDO2
         SetMotorPar(&Can_Msg_Turn_Off_TPDOX[i][1]); //关闭TPDO3

         /* 第3步  ：设置映射对象个数为0 */
         SetMotorPar(&Can_Msg_Set_Number_Mapped_objectsTo0[i][0]);   //设置TPDO2映射对象个数为 0
         SetMotorPar(&Can_Msg_Set_Number_Mapped_objectsTo0[i][1]);   //设置TPDO3映射对象个数为 0

         /* 第4步  ：设置映射内容 */
         SetMotorPar(&Can_Msg_Map_Actual_value_to_TPDOX_objectX[i][0]);//编码器映射
         SetMotorPar(&Can_Msg_Map_Actual_value_to_TPDOX_objectX[i][1]);//速度映射
         SetMotorPar(&Can_Msg_Map_Actual_value_to_TPDOX_objectX[i][2]);//状态字映射
         SetMotorPar(&Can_Msg_Map_Actual_value_to_TPDOX_objectX[i][3]);//电流值映射

         /* 第5步  ：设置映射对象个数 */
         SetMotorPar(&Can_Msg_Set_Number_Mapped_objectsTo2[i][0]);   //设置TPDO2映射对象个数为 2
         SetMotorPar(&Can_Msg_Set_Number_Mapped_objectsTo2[i][1]);   //设置TPDO3映射对象个数为 2

         /* 第6步  ：打开TPDO   */
         SetMotorPar(&Can_Msg_Turn_On_TPDOX[i][0]);//打开TPDO2
         SetMotorPar(&Can_Msg_Turn_On_TPDOX[i][1]);//打开TPDO3

         SetMotorPar(&Can_Msg_OperationEn_NO[i]);    //设置操作使能
         SetMotorPar(&Can_Msg_VelocityMode_NO[i]);   //设置速度模式
         SetMotorPar(&Can_Msg_SetAcc_NO[i]);     //设置加速度
         SetMotorPar(&Can_Msg_SetDec_NO[i]);     //设置减速度
         SetMotorPar(&Can_Msg_ChangeMotionStatusToOperation[i]);//设置为操作状态

        /* 设置启动速度为0并启动 */
         SetMotorPar(&Can_Msg_TargetVelocity_NO[i]);//设置目标速度 0

         SetMotorPar(&Can_Msg_MotionStart_NO[i]);    //启动
     }
#if DEF_DEBUG_CFG & DEF_DEBUG_PRINTF	
	DEBUG_PRINTF("[ OK ] CanopenInit success ...\r\n");
#endif
 }
 
/*****************************************************************************
 * 函 数 名  : SetMotorTargetVelocity
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 配置左右电机目标速度带速度缓存数组中并启动
 * 输入参数  : s32 vel_left   左电机转速
               s32 vel_right  有电机转速
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
  void SetMotorTargetVelocity(s32 vel_left,s32 vel_right)
  {
     u8 i;
     s32 speedleft,speedright;
 
     speedleft = vel_left;
     speedright = vel_right;
     
     data_cmd_TargetVelocity[4] = speedleft;
     data_cmd_TargetVelocity[5] = speedleft>>8;
     data_cmd_TargetVelocity[6] = speedleft>>16;
     data_cmd_TargetVelocity[7] = speedleft>>24;
     
     for(i=4;i<Can_Msg_TargetVelocity_NO[0].len;i++)
          Can_Msg_TargetVelocity_NO[0].data[i] = data_cmd_TargetVelocity[i];
 
     data_cmd_TargetVelocity[4] = speedright;
     data_cmd_TargetVelocity[5] = speedright>>8;
     data_cmd_TargetVelocity[6] = speedright>>16;
     data_cmd_TargetVelocity[7] = speedright>>24;
     
     for(i=4;i<Can_Msg_TargetVelocity_NO[1].len;i++)
         Can_Msg_TargetVelocity_NO[1].data[i] = data_cmd_TargetVelocity[i];
     StartMotion();//启动
  }
  
/*****************************************************************************
 * 函 数 名  : StartMotion
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 启动所有电机
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
  void StartMotion(void)
  {
    canSend(&hcan1,&Can_Msg_TargetVelocity_NO[0]);
    delay_ms(2);
    canSend(&hcan1,&Can_Msg_TargetVelocity_NO[1]);
    delay_ms(2);
    if(stopflag==1)   //如果已经停止过则需要重新发送电机启动命令
    {
        canSend(&hcan1,&Can_Msg_MotionStart_NO[0]);  //Start/Stop Motion
        delay_ms(2);
        canSend(&hcan1,&Can_Msg_MotionStart_NO[1]);  //Start/Stop Motion
        stopflag=0;
    }
  }
  
/*****************************************************************************
 * 函 数 名  : MotionHalts
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 停止所有电机
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
  void MotionHalts(void)
  {
     canSend(&hcan1,&Can_Msg_MotionHalts_NO[0]);
     delay_ms(2);
     canSend(&hcan1,&Can_Msg_MotionHalts_NO[1]);
     delay_ms(2);
      stopflag=1;
  }
 
 /*****************************************************************************
  * 函 数 名  : StatusWordAnalysis
  * 负 责 人  : jishubao
  * 创建日期  : 2018年11月19日
  * 函数功能  : 驱动器状态字分析函数
  * 输入参数  : void  无
  * 输出参数  : 无
  * 返 回 值  : void
  * 调用关系  : 
  * 其    它  : 
 
 *****************************************************************************/
  void StatusWordAnalysis(void)
 {
//     if((status_word_left[1]&(0x01<<3))||(status_word_right[1]&(0x01<<3)))     //判断是否出现FAULT
//     {
//         MotionHalts();
//         AbnormalReporting(1,1,3);
//     }
//      if((status_word_left[1]&(0x01<<7))||(status_word_right[1]&(0x01<<7)))     //判断是否出现FAULT
//     {
//         MotionHalts();
//         AbnormalReporting(1,1,4);
//     }
 }
 /*****************************************************************************
  * 函 数 名  : SetCanopenParameter
  * 负 责 人  : jishubao
  * 创建日期  : 2018年11月19日
  * 函数功能  : 驱动器CANopen通讯网络参数设置
  * 输入参数  : u8 id  电机编号 id
  * 输出参数  : 无
  * 返 回 值  : void
  * 调用关系  : 
  * 其    它  : 
 
 *****************************************************************************/
  void SetCanopenParameter(u8 id)
  {
    u8 i;
    /* 填充read switch结构体 */
    Can_Msg_ReadSwitch_NO[id].cob_id = id_motor_no[id];
    Can_Msg_ReadSwitch_NO[id].rtr = rtr_my;
    Can_Msg_ReadSwitch_NO[id].len = len;
    for(i=0;i<Can_Msg_ReadSwitch_NO[id].len;i++)
        Can_Msg_ReadSwitch_NO[id].data[i]  =  data_cmd_ReadSwitch[i];

    /* 填充switch on结构体 */
    Can_Msg_SwitchOn_NO[id].cob_id = id_motor_no[id];
    Can_Msg_SwitchOn_NO[id].rtr = rtr_my;
    Can_Msg_SwitchOn_NO[id].len = len;
    for(i=0;i<Can_Msg_SwitchOn_NO[id].len;i++)
        Can_Msg_SwitchOn_NO[id].data[i]  =  data_cmd_SwitchOn[i];

    /* 填充OPeration enable 结构体 */
    Can_Msg_OperationEn_NO[id].cob_id = id_motor_no[id];
    Can_Msg_OperationEn_NO[id].rtr = rtr_my;
    Can_Msg_OperationEn_NO[id].len = len;
    for(i=0;i<Can_Msg_OperationEn_NO[id].len;i++)
        Can_Msg_OperationEn_NO[id].data[i]  =  data_cmd_OperationEn[i];

    /* 填充 模式选择为速度模式 结构体 */
    Can_Msg_VelocityMode_NO[id].cob_id = id_motor_no[id];
    Can_Msg_VelocityMode_NO[id].rtr = rtr_my;
    Can_Msg_VelocityMode_NO[id].len = len;
    for(i=0;i<Can_Msg_VelocityMode_NO[id].len;i++)
     Can_Msg_VelocityMode_NO[id].data[i] =  data_cmd_VelocityMode[i];

    /* 填充 设置加速度 结构体 */
    Can_Msg_SetAcc_NO[id].cob_id = id_motor_no[id];
    Can_Msg_SetAcc_NO[id].rtr = rtr_my;
    Can_Msg_SetAcc_NO[id].len = len;
    for(i=0;i<Can_Msg_SetAcc_NO[id].len;i++)
     Can_Msg_SetAcc_NO[id].data[i] =  data_cmd_SetAcc[i];

    /* 填充 设置减速度 结构体 */
    Can_Msg_SetDec_NO[id].cob_id = id_motor_no[id];
    Can_Msg_SetDec_NO[id].rtr = rtr_my;
    Can_Msg_SetDec_NO[id].len = len;
    for(i=0;i<Can_Msg_SetDec_NO[id].len;i++)
        Can_Msg_SetDec_NO[id].data[i] =  data_cmd_SetDec[i];

    /* 填充 设置目标速度 结构体 */
    Can_Msg_TargetVelocity_NO[id].cob_id = id_motor_no[id];
    Can_Msg_TargetVelocity_NO[id].rtr = rtr_my;
    Can_Msg_TargetVelocity_NO[id].len = len;
    for(i=0;i<Can_Msg_TargetVelocity_NO[id].len;i++)
        Can_Msg_TargetVelocity_NO[id].data[i] =  data_cmd_TargetVelocity[i];

    /* 填充 设置开始运动 结构体 */
    Can_Msg_MotionStart_NO[id].cob_id = id_motor_no[id];
    Can_Msg_MotionStart_NO[id].rtr = rtr_my;
    Can_Msg_MotionStart_NO[id].len = len;
    for(i=0;i<Can_Msg_MotionStart_NO[id].len;i++)
        Can_Msg_MotionStart_NO[id].data[i] =  data_cmd_MotionStart[i];

    /* 填充 设置停止 结构体 */
    Can_Msg_MotionHalts_NO[id].cob_id = id_motor_no[id];
    Can_Msg_MotionHalts_NO[id].rtr = rtr_my;
    Can_Msg_MotionHalts_NO[id].len = len;
    for(i=0;i<Can_Msg_MotionHalts_NO[id].len;i++)
        Can_Msg_MotionHalts_NO[id].data[i] =  data_cmd_MotionHalts[i];

    /* 填充 请求实际编码器值 结构体 */
    Can_Msg_ActPosition_NO[id].cob_id = id_motor_no[id];
    Can_Msg_ActPosition_NO[id].rtr = rtr_my;
    Can_Msg_ActPosition_NO[id].len = len;
    for(i=0;i<Can_Msg_ActPosition_NO[id].len;i++)
        Can_Msg_ActPosition_NO[id].data[i] =  data_cmd_GetPosition[i];

    /* 填充 请求实际速度值 结构体 */
    Can_Msg_ActVelocity_NO[id].cob_id = id_motor_no[id];
    Can_Msg_ActVelocity_NO[id].rtr = rtr_my;
    Can_Msg_ActVelocity_NO[id].len = len;
    for(i=0;i<Can_Msg_ActVelocity_NO[id].len;i++)
        Can_Msg_ActVelocity_NO[id].data[i] =  data_cmd_GetVelActVal[i];

    /* 填充 请求实际电流值 结构体 */
    Can_Msg_ActCurrent_NO[id].cob_id = id_motor_no[id];
    Can_Msg_ActCurrent_NO[id].rtr = rtr_my;
    Can_Msg_ActCurrent_NO[id].len = len;
    for(i=0;i<Can_Msg_ActCurrent_NO[id].len;i++)
        Can_Msg_ActCurrent_NO[id].data[i] =  data_cmd_GetCurActValue[i];

    /* 填充 驱动器状态 结构体 */ 
    Can_Msg_MotionStatus_NO[id].cob_id = id_motor_no[id];
    Can_Msg_MotionStatus_NO[id].rtr = rtr_my;
    Can_Msg_MotionStatus_NO[id].len = len;
    for(i=0;i<Can_Msg_MotionStatus_NO[id].len;i++)
        Can_Msg_MotionStatus_NO[id].data[i] =  data_cmd_MotionStatus[i];


    /* 填充 驱动器id的TPDO传输类型 结构体 */ 
    Can_Msg_TPDOTRANTYPE_NO[id][0].cob_id = id_motor_no[id];
    Can_Msg_TPDOTRANTYPE_NO[id][0].rtr = rtr_my;
    Can_Msg_TPDOTRANTYPE_NO[id][0].len = len;
    for(i=0;i<Can_Msg_TPDOTRANTYPE_NO[id][0].len;i++)
        Can_Msg_TPDOTRANTYPE_NO[id][0].data[i] = data_cmd_ChangeTPDOTransType180x[0][i];

     /* 填充 驱动器 id 的TPDO传输类型 结构体 */ 
    Can_Msg_TPDOTRANTYPE_NO[id][1].cob_id = id_motor_no[id];
    Can_Msg_TPDOTRANTYPE_NO[id][1].rtr = rtr_my;
    Can_Msg_TPDOTRANTYPE_NO[id][1].len = len;
    for(i=0;i<Can_Msg_TPDOTRANTYPE_NO[id][1].len;i++)
        Can_Msg_TPDOTRANTYPE_NO[id][1].data[i] =data_cmd_ChangeTPDOTransType180x[1][i];

      /* 填充 驱动器 id 的状态切换到运行状态 结构体 */ 
    Can_Msg_ChangeMotionStatusToOperation[id].cob_id = 0x0000;
    Can_Msg_ChangeMotionStatusToOperation[id].rtr = rtr_my;
    Can_Msg_ChangeMotionStatusToOperation[id].len = 2;
    for(i=0;i<Can_Msg_ChangeMotionStatusToOperation[id].len;i++)
        Can_Msg_ChangeMotionStatusToOperation[id].data[i] =data_cmd_ChangeMotionStatusToOperation[id][i];

     /* 填充 驱动器 id 的状态切换到预运行状态 结构体 */ 
    Can_Msg_ChangeMotionStatusToPreOperation[id].cob_id = 0x0000;
    Can_Msg_ChangeMotionStatusToPreOperation[id].rtr = rtr_my;
    Can_Msg_ChangeMotionStatusToPreOperation[id].len = 2;
    for(i=0;i<Can_Msg_ChangeMotionStatusToPreOperation[id].len;i++)
        Can_Msg_ChangeMotionStatusToPreOperation[id].data[i] =data_cmd_ChangeMotionStatusToPreOperation[id][i];     

      /* 填充 驱动器 id 关闭TPDO1 结构体 */ 
    Can_Msg_Turn_Off_TPDOX[id][0].cob_id = id_motor_no[id];
    Can_Msg_Turn_Off_TPDOX[id][0].rtr = rtr_my;
    Can_Msg_Turn_Off_TPDOX[id][0].len = len;
    for(i=0;i<Can_Msg_Turn_Off_TPDOX[id][0].len;i++)
        Can_Msg_Turn_Off_TPDOX[id][0].data[i] =data_cmd_Turn_Off_TPDOX[0][i];  

    /* 填充 驱动器 id 关闭TPDO2 结构体 */ 
    Can_Msg_Turn_Off_TPDOX[id][1].cob_id = id_motor_no[id];
    Can_Msg_Turn_Off_TPDOX[id][1].rtr = rtr_my;
    Can_Msg_Turn_Off_TPDOX[id][1].len = len;
    for(i=0;i<Can_Msg_Turn_Off_TPDOX[id][1].len;i++)
        Can_Msg_Turn_Off_TPDOX[id][1].data[i] =data_cmd_Turn_Off_TPDOX[1][i];   

      /* 填充 驱动器 id 设置0X1A01映射对象个数为0 结构体 */ 
    Can_Msg_Set_Number_Mapped_objectsTo0[id][0].cob_id = id_motor_no[id];
    Can_Msg_Set_Number_Mapped_objectsTo0[id][0].rtr = rtr_my;
    Can_Msg_Set_Number_Mapped_objectsTo0[id][0].len = len;
    for(i=0;i<Can_Msg_Set_Number_Mapped_objectsTo0[id][0].len;i++)
        Can_Msg_Set_Number_Mapped_objectsTo0[id][0].data[i] =data_cmd_Set_Number_Mapped_objectsTo0[0][i];  

    /* 填充 驱动器 id 设置0X1A02映射对象个数为0 结构体 */ 
    Can_Msg_Set_Number_Mapped_objectsTo0[id][1].cob_id = id_motor_no[id];
    Can_Msg_Set_Number_Mapped_objectsTo0[id][1].rtr = rtr_my;
    Can_Msg_Set_Number_Mapped_objectsTo0[id][1].len = len;
    for(i=0;i<Can_Msg_Set_Number_Mapped_objectsTo0[id][1].len;i++)
        Can_Msg_Set_Number_Mapped_objectsTo0[id][1].data[i] =data_cmd_Set_Number_Mapped_objectsTo0[1][i];

    /* 填充 驱动器 id 设置编码器值映射到TPDO1的子索引01 4Bytes 结构体 */ 
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][0].cob_id = id_motor_no[id];
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][0].rtr = rtr_my;
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][0].len = len;
    for(i=0;i<Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][0].len;i++)
        Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][0].data[i] =data_cmd_Map_Actual_value_to_TPDOX_objectX[0][i];    

    /* 填充 驱动器 id //设置速度值映射到TPDO1的子索引02                2Bytes 结构体 */ 
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][1].cob_id = id_motor_no[id];
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][1].rtr = rtr_my;
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][1].len = len;
    for(i=0;i<Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][1].len;i++)
        Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][1].data[i] =data_cmd_Map_Actual_value_to_TPDOX_objectX[1][i];

    /* 填充 驱动器 id 设置状态字映射到TPDO2的子索引01 4Bytes 结构体 */ 
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][2].cob_id = id_motor_no[id];
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][2].rtr = rtr_my;
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][2].len = len;
    for(i=0;i<Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][2].len;i++)
        Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][2].data[i] =data_cmd_Map_Actual_value_to_TPDOX_objectX[2][i];    

    /* 填充 驱动器 id //设置电流值映射到TPDO2的子索引02                    2Bytes 结构体 */ 
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][3].cob_id = id_motor_no[id];
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][3].rtr = rtr_my;
    Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][3].len = len;
    for(i=0;i<Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][3].len;i++)
        Can_Msg_Map_Actual_value_to_TPDOX_objectX[id][3].data[i] =data_cmd_Map_Actual_value_to_TPDOX_objectX[3][i];

    /* 填充 驱动器 id 设置0X1A00映射对象个数为2 结构体 */ 
    Can_Msg_Set_Number_Mapped_objectsTo2[id][0].cob_id = id_motor_no[id];
    Can_Msg_Set_Number_Mapped_objectsTo2[id][0].rtr = rtr_my;
    Can_Msg_Set_Number_Mapped_objectsTo2[id][0].len = len;
    for(i=0;i<Can_Msg_Set_Number_Mapped_objectsTo2[id][0].len;i++)
        Can_Msg_Set_Number_Mapped_objectsTo2[id][0].data[i] =data_cmd_Set_Number_Mapped_objectsTo2[0][i];  

    /* 填充 驱动器 id 设置0X1A01映射对象个数为2 结构体 */ 
    Can_Msg_Set_Number_Mapped_objectsTo2[id][1].cob_id = id_motor_no[id];
    Can_Msg_Set_Number_Mapped_objectsTo2[id][1].rtr = rtr_my;
    Can_Msg_Set_Number_Mapped_objectsTo2[id][1].len = len;
    for(i=0;i<Can_Msg_Set_Number_Mapped_objectsTo2[id][1].len;i++)
        Can_Msg_Set_Number_Mapped_objectsTo2[id][1].data[i] =data_cmd_Set_Number_Mapped_objectsTo2[1][i];

       /* 填充 驱动器 id 打开TPDO1 结构体 */ 
    Can_Msg_Turn_On_TPDOX[id][0].cob_id = id_motor_no[id];
    Can_Msg_Turn_On_TPDOX[id][0].rtr = rtr_my;
    Can_Msg_Turn_On_TPDOX[id][0].len = len;
    for(i=0;i<Can_Msg_Turn_On_TPDOX[id][0].len;i++)
        Can_Msg_Turn_On_TPDOX[id][0].data[i] =data_cmd_Turn_On_TPDOX[0][i];  

    /* 填充 驱动器 id 打开TPDO2 结构体 */ 
    Can_Msg_Turn_On_TPDOX[id][1].cob_id = id_motor_no[id];
    Can_Msg_Turn_On_TPDOX[id][1].rtr = rtr_my;
    Can_Msg_Turn_On_TPDOX[id][1].len = len;
    for(i=0;i<Can_Msg_Turn_On_TPDOX[id][1].len;i++)
        Can_Msg_Turn_On_TPDOX[id][1].data[i] =data_cmd_Turn_On_TPDOX[1][i];   

    /* 填充 驱动器 id      SYNC报文 结构体 */ 
    Can_Msg_SYNCMY.cob_id = 0X0080;
    Can_Msg_SYNCMY.rtr = rtr_my;
    Can_Msg_SYNCMY.len = 0;

    /* 填充 驱动器 id 清除错误 结构体 */ 
    Can_Msg_DSPclearAlarm_NO[id].cob_id = id_motor_no[id];
    Can_Msg_DSPclearAlarm_NO[id].rtr = rtr_my;
    Can_Msg_DSPclearAlarm_NO[id].len = len;
    for(i=0;i<Can_Msg_DSPclearAlarm_NO[id].len;i++)
        Can_Msg_DSPclearAlarm_NO[id].data[i] =data_cmd_DSPclearAlarm[i];  
 
  }
/*****************************************************************************
 * 函 数 名  : AbnormalReporting
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 串口上报异常
 * 输入参数  : u8 type    异常类型
               u8 group   异常组
               u8 number  异常号
 * 输出参数  : 无
 * 返 回 值  : u8
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
  u8 AbnormalReporting(u8 type,u8 group,u8 number)
{
    if((type == 1)&&(group == 1||group == 2||group == 3||group == 4||group == 5))
    {
    	Set_Alarm(BJ_CMD_YELLOW_ONLY);		//设置三色灯状态为黄色
    }
    else if((type == 2)&&(group == 1 || group == 2))
    {
    	Set_Alarm(BJ_CMD_RED_ONLY);		//设置三色灯状态为红色
    }
	else
		Set_Alarm(BJ_CMD_GREEN_ONLY);
	errcode[0] = type;
	errcode[1] = group;
	errcode[2] = number;

	Date_Up_Load(ERROR_STATUS_CMD);
	return 0;
}

/*****************************************************************************
 * 函 数 名  : Turn_Left
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 整车原地左转
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
 void Turn_Left(void)
 {
     s32 vel_left, vel_right;
     
     vel_right = MOTOR_SPEED_PS2_TURN*SPEED_COEFFICIENT; 
     vel_left = -(vel_right);

     SetMotorTargetVelocity(vel_left, vel_right);//设置当前行驶速度
 }
 
/*****************************************************************************
 * 函 数 名  : Turn_Right
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 整车原地右转
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
 void Turn_Right(void)
 {
     s32 vel_left, vel_right;
     vel_left = MOTOR_SPEED_PS2_TURN*SPEED_COEFFICIENT;
     vel_right = -(vel_left);
     SetMotorTargetVelocity(vel_left, vel_right);//设置当前行驶速度
 }
 
/*****************************************************************************
 * 函 数 名  : Move_Forward
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 整车直行前进
 * 输入参数  : u8 level  整车前进电机档位
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
 void Move_Forward(u8 level)
 {
     s32 vel_left, vel_right;
     if(level == 1)
     {
         vel_left = MOTOR_SPEED_PS2_LEVEL1*SPEED_COEFFICIENT;
         vel_right = MOTOR_SPEED_PS2_LEVEL1*SPEED_COEFFICIENT;
          SetMotorTargetVelocity(vel_left, vel_right);//设置当前行驶速度
     }
     else if(level == 2)
     {
         vel_left = MOTOR_SPEED_PS2_LEVEL2*SPEED_COEFFICIENT;
         vel_right = MOTOR_SPEED_PS2_LEVEL2*SPEED_COEFFICIENT;
          SetMotorTargetVelocity(vel_left, vel_right);//设置当前行驶速度
     }
 }
 
/*****************************************************************************
 * 函 数 名  : Back_Off
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 整车直线后退
 * 输入参数  : u8 level  整车直行后退档位
 * 输出参数  : 无
 * 返 回 值  : void
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
 void Back_Off(u8 level)
 {
     s32 vel_left, vel_right;
     if(level == 1)
     {
        vel_left = -(MOTOR_SPEED_PS2_LEVEL1*SPEED_COEFFICIENT);
        vel_right = -(MOTOR_SPEED_PS2_LEVEL1*SPEED_COEFFICIENT);
        SetMotorTargetVelocity(vel_left, vel_right);//设置当前行驶速度
     }
     else if(level == 2)
     {
        vel_left = -(MOTOR_SPEED_PS2_LEVEL2*SPEED_COEFFICIENT);
        vel_right = -(MOTOR_SPEED_PS2_LEVEL2*SPEED_COEFFICIENT);
        SetMotorTargetVelocity(vel_left, vel_right);//设置当前行驶速度
     }
 }
 
/*****************************************************************************
 * 函 数 名  : Set_Speed
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 分析PC的速度指令并下发驱动器
 * 输入参数  : float leftvalue   浮点型左电机转速，单位rps
               float rightvalue  浮点型右电机转速，单位rps
 * 输出参数  : 无
 * 返 回 值  : u8
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
 u8 Set_Speed(float leftvalue,float rightvalue)
 {
     s32 lspeedrps=0,rspeedrps=0;
     const float FLT_EPSILON=0.0001f;
     
     /* 上位机发送电机转速*/ 
       if(leftvalue>50.0f||rightvalue>50.0f)
          return SPEEDOUT_ERROR;
      else if((leftvalue>=-FLT_EPSILON&&leftvalue<=FLT_EPSILON)||(rightvalue>=-FLT_EPSILON&&rightvalue<=FLT_EPSILON))  //速度为零
     {
         MotionHalts();
     }
     else
     {
      /* 上位机发送电机转速则不需要减速比与轮直径参与运算用上面的关系得到电机实际转速指令，反之用下面的关系*/ 
         lspeedrps = (s32)(leftvalue*SPEED_COEFFICIENT); //  直接得到电机转速   
         rspeedrps = (s32)(rightvalue*SPEED_COEFFICIENT);//  直接得到电机转速 
           
        // lspeedrps = (s32)(leftvalue*REDUCTION_RATIO*SPEED_COEFFICIENT); //  28为减速比  D=250mm   圆周长0.785m     
         //rspeedrps = (s32)(rightvalue*REDUCTION_RATIO*SPEED_COEFFICIENT);//  28为减速比  D=250mm   圆周长0.785m  
         
        SetMotorTargetVelocity(lspeedrps,rspeedrps);

     }   
     /*上位机发送整车速度*/    
 //  if(leftvalue>1.4f||rightvalue>1.4f)
 //      return SPEEDOUT_ERROR;
 ////    if(leftvalue==0||rightvalue==0)
 ////         MotionHalts();
 //  else if((leftvalue>=-FLT_EPSILON&&leftvalue<=FLT_EPSILON)||(rightvalue>=-FLT_EPSILON&&rightvalue<=FLT_EPSILON))  //速度为零
 //  {
 //        MotionHalts();
 //  }
 //    else
 //    {
 //        lspeedrps = (s32)(leftvalue*28000*240/785); //  28为减速比  D=250mm   圆周长0.785m     
 //        rspeedrps = (s32)(rightvalue*28000*240/785);//  28为减速比  D=250mm   圆周长0.785m  
 //        
 //       SetMotorTargetVelocity(lspeedrps,rspeedrps);
 //       StartMotion();
 //    }      
         return NO_ERROR;
 }
 
 /* CRC-16MODBUS校验  */
 unsigned short GetCRC16(u8 *ptr,u8 len)
 {
 //  unsigned char i;
 //  unsigned short crc = 0xFFFF;
     u8 i;
     u16 crc = 0xffff;
     if(len==0)
     {
         len = 1;
     }
     while(len--)
     {
         crc ^= *ptr;
         for(i=0; i<8; i++)
         {
             if(crc&1)
             {
                 crc >>= 1;
                 crc ^= 0xA001;
             }
             else
                 crc >>= 1;
         }
         ptr++;
     }
     return(crc);
 }
 /*****************************************************************************
  * 函 数 名  : Date_Up_Load
  * 负 责 人  : jishubao
  * 创建日期  : 2019年4月11日
  * 函数功能  : 数据串口上传至PC机
  * 输入参数  : u8 msgid  数据类型ID
  * 输出参数  : 无
  * 返 回 值  : 
  * 调用关系  : 
  * 其    它  : 
 
 *****************************************************************************/
 void Date_Up_Load(u8 msgid)
 {
     u16 crccheck = 0;
     u8 USART_TX_BUF[TX_LEN];
     
     memset(USART_TX_BUF, 0, TX_LEN);       //清空上位机通信串口接收缓存
     /* 帧头 */
     USART_TX_BUF[0] = 0xaa;
     USART_TX_BUF[1] = 0x55;
     
     USART_TX_BUF[4] = 0X00;     //length
     USART_TX_BUF[5] = msgid;    //type
 
     switch ( msgid )
     {
         case UPLOAD_ENCODER_AND_VELOCITY:   //上传电机编码器和速度命令
            USART_TX_BUF[4] = 16;       //数据长度
//            memcpy(&USART_TX_BUF[6], encoder_valueleft, sizeof(encoder_valueleft));
//            memcpy(&USART_TX_BUF[10], velocity_valueleft, sizeof(velocity_valueleft));
//            memcpy(&USART_TX_BUF[14], encoder_valueright, sizeof(encoder_valueright));
//            memcpy(&USART_TX_BUF[18], velocity_valueright, sizeof(velocity_valueright));
//				 /* 修改编码器、速度变量由字符数组修改为无符号32位长整形 高字节在后低字节在前 代替以上注释部分 2019.04.24-1*/
//						memcpy(&USART_TX_BUF[24], &encoder_left, sizeof(encoder_left));
//						memcpy(&USART_TX_BUF[28], &velocity_left, sizeof(velocity_left));
//				 		memcpy(&USART_TX_BUF[32], &encoder_right, sizeof(encoder_right));
//						memcpy(&USART_TX_BUF[36], &velocity_right, sizeof(velocity_right));
				 /* 修改编码器、速度变量由字符数组修改为结构体存储 高字节在后低字节在前(大于1字节) 代替以上注释部分 2019.04.24-2*/
						memcpy(&USART_TX_BUF[6], &motormsg.encoder_left, sizeof(motormsg.encoder_left));
						memcpy(&USART_TX_BUF[10], &motormsg.velocity_left, sizeof(motormsg.velocity_left));
				 		memcpy(&USART_TX_BUF[14], &motormsg.encoder_right, sizeof(motormsg.encoder_right));
						memcpy(&USART_TX_BUF[18], &motormsg.velocity_right, sizeof(motormsg.velocity_right));
				 
            break;
         case UPLOAD_STATUS_AND_CURRENT :    //上传电机状态字和电流值命令
            USART_TX_BUF[4] = 8;             //数据长度
//          memcpy(&USART_TX_BUF[6], status_word_left, sizeof(status_word_left));
//          memcpy(&USART_TX_BUF[8], current_valueleft, sizeof(current_valueleft));
//          memcpy(&USART_TX_BUF[10], status_word_right, sizeof(status_word_right));
//          memcpy(&USART_TX_BUF[12], current_valueright, sizeof(current_valueright));
//				  /* 修改状态字、电流变量由字符数组修改为无符号16位整形 高字节在后低字节在前 代替以上注释部分 2019.04.24-1*/
//				  memcpy(&USART_TX_BUF[14], &status_w_left, sizeof(status_w_left));
//          memcpy(&USART_TX_BUF[16], &current_left, sizeof(current_left));
//          memcpy(&USART_TX_BUF[18], &status_w_right, sizeof(status_w_right));
//          memcpy(&USART_TX_BUF[20], &current_right, sizeof(current_right));
				  /* 修改状态字、电流变量由字符数组修改为结构体存储 高字节在后低字节在前(大于1字节) 代替以上注释部分 2019.04.24-2*/
				  memcpy(&USART_TX_BUF[6], &motormsg.status_w_left, sizeof(motormsg.status_w_left));
          memcpy(&USART_TX_BUF[8], &motormsg.current_left, sizeof(motormsg.current_left));
          memcpy(&USART_TX_BUF[10], &motormsg.status_w_right, sizeof(motormsg.status_w_right));
          memcpy(&USART_TX_BUF[12], &motormsg.current_right, sizeof(motormsg.current_right));
             break;
         case ERROR_STATUS_CMD :
             USART_TX_BUF[4] = 3;         //数据长度
             memcpy(&USART_TX_BUF[6], errcode, sizeof(errcode));
             break;
         case BATTARY_MONITOR_MSGID_CMD:     //电池信息命令
            USART_TX_BUF[4] = 12;       //数据长度
            USART_TX_BUF[6] = battarymsg.chargingstatus ;

             USART_TX_BUF[7] = (u8)battarymsg.current;
             USART_TX_BUF[8] = battarymsg.current>>8;
             USART_TX_BUF[9] = (u8)battarymsg.voltage;
             USART_TX_BUF[10] = battarymsg.voltage>>8;

             USART_TX_BUF[11] = (u8)battarymsg.charging_times;
             USART_TX_BUF[12] = battarymsg.charging_times>>8;

             USART_TX_BUF[13] = (u8)battarymsg.remaining_total_capacity;
             USART_TX_BUF[14] = battarymsg.remaining_total_capacity>>8;
             USART_TX_BUF[15] = (u8)battarymsg.total_capacity;
             USART_TX_BUF[16] = battarymsg.total_capacity>>8;

             USART_TX_BUF[17] = battarymsg.remaining_battery_percentage;
             
//           memcpy(&USART_TX_BUF[7],&battarymsg.current,sizeof(battarymsg.current));
//           memcpy(&USART_TX_BUF[9],&battarymsg.voltage,sizeof(battarymsg.voltage));
//           memcpy(&USART_TX_BUF[11],&battarymsg.charging_times,sizeof(battarymsg.charging_times));
//           memcpy(&USART_TX_BUF[13],&battarymsg.remaining_total_capacity,sizeof(battarymsg.remaining_total_capacity));
//           memcpy(&USART_TX_BUF[15],&battarymsg.total_capacity,sizeof(battarymsg.total_capacity));                             
//           USART_TX_BUF[17] = battarymsg.remaining_battery_percentage;
             break;
         case INFRARED_DISTANCE_CMD:     //红外数据上报命令
					 USART_TX_BUF[4] = 8;    //数据长度，4组红外
//          memcpy(&USART_TX_BUF[6],&hw_dis[1],sizeof(hw_dis[0]));
//          memcpy(&USART_TX_BUF[8],&hw_dis[0],sizeof(hw_dis[1]));
//          memcpy(&USART_TX_BUF[10],&hw_dis[2],sizeof(hw_dis[2]));
//          memcpy(&USART_TX_BUF[12],&hw_dis[3],sizeof(hw_dis[3]));
            break;
         default:
            break;
     }
     
     /* 计算CRC校验位 */
     crccheck = GetCRC16(&USART_TX_BUF[6],USART_TX_BUF[4]);
		 memcpy(&USART_TX_BUF[2],&crccheck,sizeof(crccheck));
//	 USART_TX_BUF[2]=(u8)crccheck;
//	 USART_TX_BUF[3]=crccheck>>8;
		 /* 回车换行 用于串口打印调试 */
//		 USART_TX_BUF[USART_TX_BUF[4]+6] = 0x0d;
//		 USART_TX_BUF[USART_TX_BUF[4]+7] = 0x0a;

     /* 如果数据长度 != 0 则发送数据*/
     if(USART_TX_BUF[4])
     {
         if(USART1_Send_DMA(USART_TX_BUF, USART_TX_BUF[4]+6) == HAL_OK)
					USART_TX_BUF[4]++ ;//发送串口数据，6是指2字节帧头+1字节数据类型+1字节数据包长度+2字节校验位
			 
     }
 }
 /*****************************************************************************
 * 函 数 名  : GetValStatus
 * 负 责 人  : jishubao
 * 创建日期  : 2018年11月21日
 * 函数功能  : 将驱动器上报报文状态字数据保存在状态字缓存区
 * 输入参数  : u8 idnode  驱动器ID
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void GetValStatus(u8 idnode)
{
	if(idnode==1)
	{
		/* 第1种数据格式为数组形式保存 */
		status_word_left[0]  = RxMSG.data[1];
		status_word_left[1]  = RxMSG.data[0];
		/* 第2种数据格式为u32整型形式保存 */
		memcpy(&status_w_left,RxMSG.data,sizeof(status_w_left));
			/* 第3种数据格式为结构体形式保存 */
		memcpy(&motormsg.status_w_left,RxMSG.data,sizeof(motormsg.status_w_left));
	}
	if(idnode==2)
	{
		status_word_right[0]  = RxMSG.data[1];
		status_word_right[1]  = RxMSG.data[0];
		
		memcpy(&status_w_right,RxMSG.data,sizeof(status_w_right));
		
		memcpy(&motormsg.status_w_right,RxMSG.data,sizeof(motormsg.status_w_right));
	}
	if(RxMSG.data[1]&0x08)//bit3表示状态出现错误
		{;
		}	
}

/*****************************************************************************
 * 函 数 名  : GetValCurrent
 * 负 责 人  : jishubao
 * 创建日期  : 2018年11月21日
 * 函数功能  : 将驱动器上报报文电流数据保存在电流缓存             区
 * 输入参数  : u8 idnode  驱动器ID
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void GetValCurrent(u8 idnode)
{
	if(idnode==1)
	{
		/* 第1种数据格式为数组形式保存 */
		current_valueleft[0] = RxMSG.data[3];
		current_valueleft[1] = RxMSG.data[2];
		/* 第2种数据格式为u32整型形式保存 */
		memcpy(&current_left,&RxMSG.data[2],sizeof(current_left));
		/* 第3种数据格式为结构体形式保存 */
		memcpy(&motormsg.current_left,&RxMSG.data[2],sizeof(motormsg.current_left));
	}
	if(idnode==2)
	{
		current_valueright[0] = RxMSG.data[3];
		current_valueright[1] = RxMSG.data[2];
		
		memcpy(&current_right,&RxMSG.data[2],sizeof(current_right));
		
		memcpy(&motormsg.current_right,&RxMSG.data[2],sizeof(motormsg.current_right));
	}
}
/*****************************************************************************
 * 函 数 名  : GetValEncoder
 * 负 责 人  : jishubao
 * 创建日期  : 2018年11月21日
 * 函数功能  : 将驱动器上报报文编码器数据保存在编码器缓存区
 * 输入参数  : u8 idnode  驱动器ID
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void GetValEncoder(u8 idnode)
{
	if(idnode==1)
	{
		/* 第1种数据格式为数组形式保存 */
		encoder_valueleft[0]=RxMSG.data[0];
		encoder_valueleft[1]=RxMSG.data[1];
		encoder_valueleft[2]=RxMSG.data[2];
		encoder_valueleft[3]=RxMSG.data[3];
		/* 第2种数据格式为u32整型形式保存 */
		memcpy(&encoder_left,RxMSG.data,sizeof(encoder_left));
		/* 第3种数据格式为结构体形式保存 */
		memcpy(&motormsg.encoder_left,RxMSG.data,sizeof(motormsg.encoder_left));
//		printf(" %d \r\n",encoder_left);
//		memset(&encoder_left,0,4);
	}
	if(idnode==2)
	{
		encoder_valueright[0]=RxMSG.data[0];
		encoder_valueright[1]=RxMSG.data[1];
		encoder_valueright[2]=RxMSG.data[2];
		encoder_valueright[3]=RxMSG.data[3];
		
		memcpy(&encoder_right,RxMSG.data,sizeof(encoder_right));
		
		memcpy(&motormsg.encoder_right,RxMSG.data,sizeof(motormsg.encoder_right));
//		printf(" %d \r\n",encoder_right);
	}

}

/*****************************************************************************
 * 函 数 名  : GetValVelocity
 * 负 责 人  : jishubao
 * 创建日期  : 2018年11月21日
 * 函数功能  : 将驱动器上传电机速度转换成轮子转速
 * 输入参数  : u8 idnode  驱动器ID
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void GetValVelocity(u8 idnode)
{
  s16 valueright,valueleft;
	float right,left;

	if(idnode==1)
	{
			memcpy(&valueleft, &RxMSG.data[4], sizeof(valueleft));
        /* 下位机直接反馈电机转速给上位机，不需要计算整车速度（可以不用考虑轮子直径标定值） */
            left = (float)valueleft/SPEED_COEFFICIENT;//(REDUCTION_RATIO*SPEED_COEFFICIENT);      //REDUCTION_RATIO 减速比28    SPEED_COEFFICIENT 电机转速系数 240  
		
		/* 第1种数据格式为数组形式保存 */
			memcpy(velocity_valueleft, &left, sizeof(left));  
		/* 第2种数据格式为u32整型形式保存 */
			memcpy(&velocity_left, &left, sizeof(left));
		/* 第3种数据格式为结构体形式保存 */
		memcpy(&motormsg.velocity_left,&left,sizeof(motormsg.velocity_left));
        /* 下位机根据轮子直径和当前转速得到车子整体速度 */
//			left = (float)valueleft*785/(240*28*1000);//velocity_valueright/240得到电机速度rps，除以减速比28得到1s内轮子转的圈数再乘圆周0.785m得到整车速度单位m/s
//			memcpy(velocity_valueleft, &left, sizeof(left));

	}
	if(idnode==2)
	{
		  memcpy(&valueright, &RxMSG.data[4], sizeof(valueright));
         /* 下位机直接反馈电机转速给上位机，不需要计算整车速度（可以不用考虑轮子直径标定值） */
			right = (float)valueright/SPEED_COEFFICIENT;//(REDUCTION_RATIO*SPEED_COEFFICIENT);
			memcpy(velocity_valueright, &right, sizeof(right));
		
			memcpy(&velocity_right, &right, sizeof(right));
		
			memcpy(&motormsg.velocity_right,&right,sizeof(motormsg.velocity_right));
        /* 下位机根据轮子直径和当前转速得到车子整体速度 */
//			right = (float)valueright*785/(240*28*1000);//velocity_valueright/240得到电机速度rps，除以减速比28得到1s内轮子转的圈数再乘圆周0.785m得到整车速度单位m/s
//			memcpy(velocity_valueright, &right, sizeof(right));
	}
}


/*****************************************************************************
 * 函 数 名  : AnalysisMessagefromDriver
 * 负 责 人  : jishubao
 * 创建日期  : 2018年11月21日
 * 函数功能  : 分析驱动器上报报文，得到左右轮编码器值-
                   ，速度值，状态字，电流值
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void AnalysisMessagefromDriver(void)
{
	 uint32_t left_receivecnt = 0 ,right_receivecnt = 0;
    switch (RxMSG.cob_id)
    {
        case 0X0281://1号驱动器编码器及速度值报文
                    GetValEncoder(1);
                    GetValVelocity(1);
										right_receivecnt++;
            break;
        case 0X0381://1号驱动器状态字及电流值报文
                    GetValStatus(1);
                    GetValCurrent(1);
										right_receivecnt++;
            break;
        case 0X0282://2号驱动器编码器及速度值报文
                    GetValEncoder(2);
                    GetValVelocity(2);
										left_receivecnt++;
            break;
        case 0X0382://2号驱动器状态字及电流值报文
                    GetValStatus(2);
                    GetValCurrent(2);
										right_receivecnt++;
            break;
		case 0X0581:	//其他报文
		case 0X0582:
					if(RxMSG.data[0]!=0x60)
						startcmdstatus=1;
			break;

        default:
            break;            
    }
		if(abs(left_receivecnt-right_receivecnt)>10)//如果左右轮的返回值反馈时间差较大认为单轮失联
			{
				//单轮失联控制逻辑
				MotionHalts();//左右电机立即停止;
				AbnormalReporting(0x02,0x01,0x01);//上报异常
			}		
}

/*****************************************************************************
 * 函 数 名  : HeartbeatDetection
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 上位机控制指令心跳检测
 * 输入参数  : uint16_t *time  与PC机通信最大时间地址
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 如果大于 HEARTBEATTIME 则认为与上位机失联，立即停止并上报错误

*****************************************************************************/
void HeartbeatDetection(uint16_t *time)
{
	if( *time > HEARTBEATTIME)//下位机与上位机失去连接
	{
		MotionHalts();//左右电机立即停止
		*time = 0;
		AbnormalReporting(1,1,1);
	}
	else
		Set_Alarm(BJ_CMD_GREEN_ONLY);
} 
u32 temp1 = 0;
u32 temp2 = 0;
char buff[100];
/*****************************************************************************
 * 函 数 名  : Mode_CTL_TO_PC
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : PC机控制模式
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Mode_CTL_TO_PC(void)
{  
    static u32 cnt = 0;
    static u16 Heartbeat = 0;
	static u8 data_pc_len = 0;
static u32 tnow = 0;
 
#if DEF_DEBUG_CFG & DEF_DEBUG_CAN	
	DEBUG_PRINTF("encoder_l: %d \t velocity_l: %d \t encoder_r: %d \t velocity_r: %d\r\n",encoder_valueleft[0],velocity_valueleft[0],encoder_valueright[0],velocity_valueright[0]);
#endif
    if(1)
    {
////				printf("encoder_left %d encoder_right %d\r\n",encoder_left,encoder_right);
////				printf("motormsg.encoder_left %d motormsg.encoder_right %d\r\n",motormsg.encoder_left,motormsg.encoder_right);
//			sprintf(buff,"\r\nleft:%d \t right: %d \t memcpy(&USART_TX_BUF[40], &motormsg.encoder_left, sizeof(motormsg.encoder_left));\r\n",motormsg.encoder_left,motormsg.encoder_right);
//			USART1_Send_DMA((u8 *)buff,strlen(buff));
////			printf("left:%d \t right: %d \t\r\n",*(u32 *)&encoder_valueleft,*(u32 *)&encoder_valueright);
			
			Date_Up_Load(UPLOAD_ENCODER_AND_VELOCITY); //封装编码器&速度数据并上传
#if DEF_DEBUG_CFG & DEF_DEBUG_CAN	
		DEBUG_PRINTF("status_l:%d \t velocity_l: %d \t status_r: %d \t velocity_r: %d\r\n",status_word_left[0],current_valueleft[0],status_word_right[0],current_valueright[0]);
#endif
			if(cnt%2==0)
			{
        Date_Up_Load(UPLOAD_STATUS_AND_CURRENT); //封装状态字&电流数据并上传
			}
#ifdef FRE_UPLOAD_DATA     /* 计算上传频率 */
        printf("\r\n%d\r\n",SysTick->VAL-tnow);
			tnow = SysTick->VAL;
#endif
        StatusWordAnalysis();
			if(cnt%20==0)
        LED_RUN_Toggle();
    }
	/* begin 可以用此段注释内容代替下面串口接收数据判断内容 */
//	USART2_Read_DMA(recvfromPCbuf,&data_pc_len);
//	if(data_pc_len)
//	{
//		PC_Data_Analysis(recvfromPCbuf);
//		Heartbeat = 0;
//		data_pc_len = 0;
//	}
	/* end 可以用此段注释内容代替下面串口接收数据判断内容 */
    if(UsartType.RX_flag)
    {
        memcpy(recvfromPCbuf,UsartType.RX_pData,UsartType.RX_Size);
        PC_Data_Analysis(recvfromPCbuf);
        UsartType.RX_flag = 0;
        Heartbeat = 0;
    }
//#ifdef DEBUG_BATTERY
//    if(cnt%225==0)//(100*60*10)) 30000大概上传周期为 400s周期
//    {
//        RequestBatteryInformation(&battarymsg);
//        Date_Up_Load(BATTARY_MONITOR_MSGID_CMD);
//    }
//#endif
//#ifdef DEBUG_INFRARED_DIS
//    if(cnt%30==0)//(100*60*10)) 30 大概上传周期为0.3s 
//    {
//    	//Get_Distance_Infrared(hw_dis);
//    	Date_Up_Load(INFRARED_DISTANCE_CMD);
//    }
//#endif
#if DEBUG_PROTECT_IO
	while(PZ_CHECK == 1)	//碰撞开关检测
	{
		MotionHalts();
		AbnormalReporting(0x02,0x02,0x02);//上报异常	
	}
	while(EMERSTOP == 1)	//急停开关检测
	{
		MotionHalts();
		AbnormalReporting(0x02,0x02,0x01);//上报异常
	}
	if(PZ_CHECK == 0 && EMERSTOP == 0) //无异常后亮绿灯
	{
		Set_Alarm(BJ_CMD_GREEN_ONLY);
	}
#endif

    HeartbeatDetection(&Heartbeat);
    cnt++;
    Heartbeat++;
}

/*****************************************************************************
 * 函 数 名  : Mode_CTL_TO_PS2
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : PS2遥控手柄控制
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Mode_CTL_TO_PS2(void)
{
    Get_Swerve_Speed_PS2(); //处于手动遥控模式下
    LED_ALARM_Toggle();
}


