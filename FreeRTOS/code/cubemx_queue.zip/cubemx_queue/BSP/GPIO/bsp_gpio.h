#ifndef __BSP_GPIO_H
#define __BSP_GPIO_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "main.h"



/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */
#define DEBUG_PROTECT_IO  0 //0为取消急停等保护开关，1为打开急停等保护开关
	 
#define AUTOMODE            HAL_GPIO_ReadPin(CMODE_GPIO_Port, CMODE_Pin)
#define PZ_CHECK            HAL_GPIO_ReadPin(PZ_SW_GPIO_Port, PZ_SW_Pin)
#define EMERSTOP	 		HAL_GPIO_ReadPin(EMT_SW_GPIO_Port, EMT_SW_Pin)
#define HW1_SW_STOP         HAL_GPIO_ReadPin(HW_SW1_GPIO_Port, HW_SW1_Pin)
#define HW2_SW_STOP	 		HAL_GPIO_ReadPin(HW_SW2_GPIO_Port, HW_SW2_Pin)
	 
#define LED_RUN_ON() 		HAL_GPIO_WritePin(LED_RUN_GPIO_Port, LED_RUN_Pin, GPIO_PIN_SET)
#define LED_ALARM_ON() 		HAL_GPIO_WritePin(LED_ALARM_GPIO_Port, LED_ALARM_Pin, GPIO_PIN_SET)
#define LED_RUN_OFF() 		HAL_GPIO_WritePin(LED_RUN_GPIO_Port, LED_RUN_Pin, GPIO_PIN_RESET)
#define LED_ALARM_OFF() 	HAL_GPIO_WritePin(LED_ALARM_GPIO_Port, LED_ALARM_Pin, GPIO_PIN_RESET)
#define LED_RUN_Toggle() 	HAL_GPIO_TogglePin(LED_RUN_GPIO_Port, LED_RUN_Pin)
#define LED_ALARM_Toggle() 	HAL_GPIO_TogglePin(LED_ALARM_GPIO_Port, LED_ALARM_Pin)

#define YUNTAI_ON           HAL_GPIO_WritePin(YUNTAI_GPIO_Port, YUNTAI_Pin, GPIO_PIN_SET)
#define YUNTAI_OFF          HAL_GPIO_WritePin(YUNTAI_GPIO_Port, YUNTAI_Pin, GPIO_PIN_RESET)

#define BJ_RED_ON           HAL_GPIO_WritePin(BJ_RED_GPIO_Port, BJ_RED_Pin, GPIO_PIN_SET)
#define BJ_RED_OFF          HAL_GPIO_WritePin(BJ_RED_GPIO_Port, BJ_RED_Pin, GPIO_PIN_RESET)
#define BJ_GREEN_ON         HAL_GPIO_WritePin(BJ_GREEN_GPIO_Port, BJ_GREEN_Pin, GPIO_PIN_SET)
#define BJ_GREEN_OFF        HAL_GPIO_WritePin(BJ_GREEN_GPIO_Port, BJ_GREEN_Pin, GPIO_PIN_RESET)
#define BJ_YELLOW_ON        HAL_GPIO_WritePin(BJ_YELLOW_GPIO_Port, BJ_YELLOW_Pin, GPIO_PIN_SET)
#define BJ_YELLOW_OFF       HAL_GPIO_WritePin(BJ_YELLOW_GPIO_Port, BJ_YELLOW_Pin, GPIO_PIN_RESET)

//开发板按键
#define KEY0_Pin 			GPIO_PIN_4
#define KEY0_GPIO_Port 		GPIOE
#define KEY1_Pin 			GPIO_PIN_3
#define KEY1_GPIO_Port 		GPIOE
#define KEY2_Pin 			GPIO_PIN_2
#define KEY2_GPIO_Port 		GPIOE
#define KEY_UP_Pin 			GPIO_PIN_0
#define KEY_UP_GPIO_Port 	GPIOA
/*下面的方式是通过直接操作库函数方式读取IO*/
#define KEY0 		HAL_GPIO_ReadPin(KEY0_GPIO_Port,KEY0_Pin) //PE4
#define KEY1 		HAL_GPIO_ReadPin(KEY1_GPIO_Port,KEY1_Pin)	//PE3 
#define KEY2 		HAL_GPIO_ReadPin(KEY2_GPIO_Port,KEY2_Pin) //PE2
#define WK_UP 		HAL_GPIO_ReadPin(KEY_UP_GPIO_Port,KEY_UP_Pin)	//PA0

#define KEY0_PRES 	1
#define KEY1_PRES	2
#define KEY2_PRES	3
#define WKUP_PRES   4
extern uint8_t key0_value;
extern uint8_t key1_value;
extern uint8_t key2_value;
extern uint8_t keyup_value;

typedef enum BJ_LED_CMD
{
    BJ_CMD_RED_ONLY = 1,
    BJ_CMD_GREEN_ONLY,
    BJ_CMD_YELLOW_ONLY,
    BJ_CMD_BUZZER_ONLY,
    BJ_CMD_RED_BUZZER,
    BJ_CMD_YELLOW_BUZZER,   
}BJ_LED_CMD_ENUM;



/* USER CODE END Private defines */



/* USER CODE BEGIN Prototypes */
void KEY_Init(void);
uint8_t KEY_Scan(uint8_t mode);
void delay_us(uint32_t nus);
void delay_ms(uint32_t nms);
void Mode_Select(void);
void Set_Yuntai(uint8_t cmd);
void Set_Alarm(uint8_t cmd);
uint8_t Wireless_Charging_Status(uint8_t cmd);

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif
#endif /*__ pinoutConfig_H */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
