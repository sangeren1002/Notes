/* Includes ------------------------------------------------------------------*/
#include "bsp_gpio.h"
#include "cmsis_os.h"

uint16_t tim6cnt = 0;
uint8_t key0_value = 0;
uint8_t key1_value = 0;
uint8_t key2_value = 0;
uint8_t keyup_value = 0;
//按键初始化函数
void KEY_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStruct;

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOE_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();

	GPIO_InitStruct.Pin = KEY0_Pin|KEY1_Pin|KEY2_Pin; //KEY0 KEY1 KEY2对应引脚
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;//普通输入模式
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;//100M
	GPIO_InitStruct.Pull = GPIO_PULLUP;//上拉
	HAL_GPIO_Init(KEY0_GPIO_Port, &GPIO_InitStruct);//初始化GPIOE2,3,4

	GPIO_InitStruct.Pin = KEY_UP_Pin; //KEY0 KEY1 KEY2对应引脚
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;//普通输入模式
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;//100M
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;//上拉
	HAL_GPIO_Init(KEY_UP_GPIO_Port, &GPIO_InitStruct);//初始化GPIOE2,3,4
 
} 
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	static uint16_t cnt[4] = {0};
	
	switch(GPIO_Pin)
	{
	
		case KEY0_Pin:
			if(tim6cnt>cnt[0]+1)
			{
				cnt[0] = tim6cnt;
				key0_value = KEY0_PRES;	
				printf("KEY0_PRES\r\n");
			}
			
			break;
		case KEY1_Pin:
			if(tim6cnt>cnt[1]+1)
			{
				cnt[1] = tim6cnt;
				key1_value = KEY1_PRES;	
				printf("KEY1_PRES\r\n");
			}
			
			break;
		case KEY2_Pin:
			if(tim6cnt>cnt[2]+1)
			{
				cnt[2] = tim6cnt;
				key2_value = KEY2_PRES;		
				printf("KEY2_PRES\r\n");
			}
			
			break;
		case KEY_UP_Pin:
			if(tim6cnt>cnt[3]+1)
			{
				cnt[3] = tim6cnt;
				keyup_value = WKUP_PRES;	
				printf("WKUP_PRES\r\n");
			}
			
			break;	
	}
}
//按键处理函数
//返回按键值
//mode:0,不支持连续按;1,支持连续按;
//0，没有任何按键按下
//1，KEY0按下
//2，KEY1按下
//3，KEY2按下 
//4，WKUP按下 WK_UP
//注意此函数有响应优先级,KEY0>KEY1>KEY2>WK_UP!!
uint8_t KEY_Scan(uint8_t mode)
{	 
	static uint8_t key_up=1;//按键按松开标志
	
	if(mode)key_up=1;  //支持连按		  
	if(key_up&&(KEY0==0||KEY1==0||KEY2==0||WK_UP==1))
	{
//		delay_ms(10);
		key_up=0;
		if(KEY0==0)return 1;
		else if(KEY1==0)return 2;
		else if(KEY2==0)return 3;
		else if(WK_UP==0)return 4;
	}else if(KEY0==1&&KEY1==1&&KEY2==1&&WK_UP==1)key_up=1; 	    
 	return 0;// 无按键按下
}
static uint8_t  fac_us=0;							//us延时倍乘数			   
static uint16_t fac_ms=0;							//ms延时倍乘数,在os下,代表每个节拍的ms数
//延时nus
//nus:要延时的us数.	
//nus:0~204522252(最大值即2^32/fac_us@fac_us=168)	    								   
void delay_us(uint32_t nus)
{		
	uint32_t ticks;
	uint32_t told,tnow,tcnt=0;
	uint32_t reload=SysTick->LOAD;				//LOAD的值	    	 
	ticks=nus*fac_us; 						//需要的节拍数 
	told=SysTick->VAL;        				//刚进入时的计数器值
	while(1)
	{
		tnow=SysTick->VAL;	
		if(tnow!=told)
		{	    
			if(tnow<told)tcnt+=told-tnow;	//这里注意一下SYSTICK是一个递减的计数器就可以了.
			else tcnt+=reload-tnow+told;	    
			told=tnow;
			if(tcnt>=ticks)break;			//时间超过/等于要延迟的时间,则退出.
		}  
	};										    
}  
//延时nms
//nms:要延时的ms数
//nms:0~65535
void delay_ms(uint32_t nms)
{	
	if(xTaskGetSchedulerState()!=taskSCHEDULER_NOT_STARTED)//系统已经运行
	{		
		if(nms>=fac_ms)						//延时的时间大于OS的最少时间周期 
		{ 
   			vTaskDelay(nms/fac_ms);	 		//FreeRTOS延时
		}
		nms%=fac_ms;						//OS已经无法提供这么小的延时了,采用普通方式延时    
	}
	delay_us((uint32_t)(nms*1000));				//普通方式延时
}
/*****************************************************************************
 * 函 数 名  : Mode_Select
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 控制模式判断
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Mode_Select(void)
{
//    if(AUTOMODE)
//    {
//        Mode_CTL_TO_PS2();  //PS2遥控手柄模式
//    }
//    else 
//    {
//        Mode_CTL_TO_PC();   //PC机控制模式
//    }
//	Mode_CTL_TO_PC();   //PC机控制模式
        
}
/*****************************************************************************
 * 函 数 名  : Set_Yuntai
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 设置云台状态
 * 输入参数  : s8 cmd  云台控制命令
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Set_Yuntai(uint8_t cmd)
{
//    if(cmd == 0x01) //开启云台
//        YUNTAI_ON;
//    else            //关闭云台
//        YUNTAI_OFF;

}

/*****************************************************************************
 * 函 数 名  : Set_Alarm
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 设置报警灯状态
 * 输入参数  : s8 cmd  报警灯控制命令
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Set_Alarm(uint8_t cmd)
{
//    switch ( cmd )
//    {
//        case BJ_CMD_RED_ONLY ://只开启状态灯红灯
//            BJ_RED_ON;
//            BJ_GREEN_OFF;
//            BJ_YELLOW_OFF;
//            break;
//        case BJ_CMD_GREEN_ONLY ://只开启状态灯绿灯
//            BJ_GREEN_ON;
//            BJ_RED_OFF;
//            BJ_YELLOW_OFF;
//            break;
//        case BJ_CMD_YELLOW_ONLY ://只开启状态灯黄灯
//            BJ_YELLOW_ON;
//            BJ_RED_OFF;
//            BJ_GREEN_OFF;
//            break;
//        default:                    //cmd非法，只开启状态灯绿灯
//            BJ_GREEN_ON;
//            BJ_RED_OFF;
//            BJ_YELLOW_OFF;
//            break;
//    }
}

/*****************************************************************************
 * 函 数 名  : Wireless_Charging_Status
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 无线充电状态设置
 * 输入参数  : s8 cmd  无线充电控制命令
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
uint8_t Wireless_Charging_Status(uint8_t cmd)
{

//    if(cmd ==0x00) WXCD_EN=0;       //无线充电开关关闭
//    else if(cmd == 0x01)WXCD_EN=1;  //无线充电开关打开，开始充电
    return 0;
}



/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
