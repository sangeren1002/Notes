/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2019 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */     
#include "bsp_usart.h"
#include "bsp_timer.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */


MSG DATAMSG;
MSG * TXMSG = &DATAMSG;
MSG * RXMSG = &DATAMSG;
MSG * RXMSG_ISR = &DATAMSG;
MSG * TXMSGTIM = &DATAMSG;
USART_RECEIVETYPE *Usart1_DATA_SEND = &UsartTypeInit;
USART_RECEIVETYPE *Usart1_DATA_RECV = &UsartTypeInit;
uint8_t buff[20];
uint8_t htim_i = 0;

osThreadId my01_TaskHandle;
osThreadId my02_TaskHandle;

/* USER CODE END Variables */
osThreadId KEY_SCAN_TaskHandle;
osThreadId SerialTaskHandle;
osThreadId LED_TaskHandle;
osMessageQId myQueue01Handle;
osMessageQId myQueue02Handle;
osMessageQId myQueue03Handle;
osMessageQId myQueue04Handle;
osMessageQId myQueue05Handle;
osTimerId TimerSensorHandle;
osTimerId myTimer02Handle;
osMutexId myMutex01Handle;
osSemaphoreId myBinarySem01Handle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void Show_SYS_INFO_Task(void);   
uint8_t Get_Key_Value(void);
void my01_TaskStart(void const * argument);
void my02_TaskStart(void const * argument);
/* USER CODE END FunctionPrototypes */

void StartPrintfTask(void const * argument);
void SerialTaskStart(void const * argument);
void LED_TaskStart(void const * argument);
void CallbackTimerSensor(void const * argument);
void Callback02(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void configureTimerForRunTimeStats(void);
unsigned long getRunTimeCounterValue(void);

/* USER CODE BEGIN 1 */
/* Functions needed when configGENERATE_RUN_TIME_STATS is on */
__weak void configureTimerForRunTimeStats(void)
{
	ulHighFrequencyTimerTicks = 0ul;
}

__weak unsigned long getRunTimeCounterValue(void)
{
	return ulHighFrequencyTimerTicks;;
}
/* USER CODE END 1 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
       
  /* USER CODE END Init */

  /* Create the mutex(es) */
  /* definition and creation of myMutex01 */
  osMutexDef(myMutex01);
  myMutex01Handle = osMutexCreate(osMutex(myMutex01));

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of myBinarySem01 */
  osSemaphoreDef(myBinarySem01);
  myBinarySem01Handle = osSemaphoreCreate(osSemaphore(myBinarySem01), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* definition and creation of TimerSensor */
  osTimerDef(TimerSensor, CallbackTimerSensor);
  TimerSensorHandle = osTimerCreate(osTimer(TimerSensor), osTimerPeriodic, NULL);

  /* definition and creation of myTimer02 */
  osTimerDef(myTimer02, Callback02);
  myTimer02Handle = osTimerCreate(osTimer(myTimer02), osTimerPeriodic, NULL);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of KEY_SCAN_Task */
  osThreadDef(KEY_SCAN_Task, StartPrintfTask, osPriorityHigh, 0, 512);
  KEY_SCAN_TaskHandle = osThreadCreate(osThread(KEY_SCAN_Task), NULL);

  /* definition and creation of SerialTask */
  osThreadDef(SerialTask, SerialTaskStart, osPriorityNormal, 0, 256);
  SerialTaskHandle = osThreadCreate(osThread(SerialTask), NULL);

  /* definition and creation of LED_Task */
  osThreadDef(LED_Task, LED_TaskStart, osPriorityBelowNormal, 0, 256);
  LED_TaskHandle = osThreadCreate(osThread(LED_Task), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
    osThreadDef(my01_Task, my01_TaskStart, osPriorityBelowNormal, 0, 512);
	my01_TaskHandle = osThreadCreate(osThread(my01_Task), NULL);
	
	osThreadDef(my02_Task, my02_TaskStart, osPriorityBelowNormal, 0, 512);
	my02_TaskHandle = osThreadCreate(osThread(my02_Task), NULL);
  /* USER CODE END RTOS_THREADS */

  /* Create the queue(s) */
  /* definition and creation of myQueue01 */
/* what about the sizeof here??? cd native code */
  osMessageQDef(myQueue01, 32, uint8_t);
  myQueue01Handle = osMessageCreate(osMessageQ(myQueue01), NULL);

  /* definition and creation of myQueue02 */
/* what about the sizeof here??? cd native code */
  osMessageQDef(myQueue02, 32, uint8_t);
  myQueue02Handle = osMessageCreate(osMessageQ(myQueue02), NULL);

  /* definition and creation of myQueue03 */
/* what about the sizeof here??? cd native code */
  osMessageQDef(myQueue03, 32, uint8_t);
  myQueue03Handle = osMessageCreate(osMessageQ(myQueue03), NULL);

  /* definition and creation of myQueue04 */
/* what about the sizeof here??? cd native code */
  osMessageQDef(myQueue04, 32, uint8_t);
  myQueue04Handle = osMessageCreate(osMessageQ(myQueue04), NULL);

  /* definition and creation of myQueue05 */
/* what about the sizeof here??? cd native code */
  osMessageQDef(myQueue05, 32, uint8_t);
  myQueue05Handle = osMessageCreate(osMessageQ(myQueue05), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
}

/* USER CODE BEGIN Header_StartPrintfTask */
/**
  * @brief  Function implementing the PrintfTask thread.
  * @param  argument: Not used 
  * @retval None
  */
/* USER CODE END Header_StartPrintfTask */
void StartPrintfTask(void const * argument)
{

  /* USER CODE BEGIN StartPrintfTask */
	uint8_t key_val = 0;
	uint8_t i,j;
	


  /* Infinite loop */
  for(;;)
  {
	  key_val = 0;
		key_val = Get_Key_Value(); 
	  if(key_val == 1)
	  {
	    osTimerStart(TimerSensorHandle, 10);
		printf("KEY0_PRES \r\n osSemaphoreRelease(myBinarySem01Handle) [ OK ]\r\n");
		 osSemaphoreRelease(myBinarySem01Handle);
	  }
	  else	if(key_val == 2)
	  {
		printf("KEY1_PRES\r\n");
		TXMSG->ucMessageID = 1;
		for(i=0;i<20;i++,j++)
		{
			TXMSG->ucData[i]=j;
		}
		if(xQueueSend(myQueue02Handle,(void*)&TXMSG,0) ==errQUEUE_FULL)
		{
			printf("myQueue02Handle errQUEUE_FULL\r\n");
		}
		else
			printf("myQueue02Handle xQueueSend [ OK ] TXMSG->ucMessageID = %d\r\n",TXMSG->ucMessageID);
		
//		Usart1_DATA_SEND->RX_flag = 1;
//        Usart1_DATA_SEND->RX_Size = 2;
//        Usart1_DATA_SEND->RX_pData[0] = 0X01;
//		if(xQueueSend( myQueue03Handle, (void*)&Usart1_DATA_SEND, 0) == errQUEUE_FULL)
//		{
//			printf("myQueue03Handle errQUEUE_FULL\r\n");
//		}
//		else
//			printf("myQueue03Handle xQueueSend [ OK ]\r\n");
		
	  }
	  else	if(key_val == 3)
	  {
		printf("KEY2_PRES\r\n");
		if(xQueueSend(myQueue01Handle,(void*)&key_val,10) == errQUEUE_FULL)
		{
			printf("myQueue01Handle errQUEUE_FULL\r\n");
		}
		else
			printf("myQueue01Handle xQueueSend [ OK ] key_val = %d\r\n",key_val);
	  }
	  else	if(key_val == 4)
	  {
		printf("KEYUP_PRES\r\n");
		  Show_SYS_INFO_Task();
	  }
	
    osDelay(100);
  }
  /* USER CODE END StartPrintfTask */
}

/* USER CODE BEGIN Header_SerialTaskStart */
/**
* @brief Function implementing the SerialTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_SerialTaskStart */
void SerialTaskStart(void const * argument)
{
  /* USER CODE BEGIN SerialTaskStart */
  /* Infinite loop */
  for(;;)
  {
//	Analysis_Serial_Data();
	osDelay(1);
  }
  /* USER CODE END SerialTaskStart */
}

/* USER CODE BEGIN Header_LED_TaskStart */
/**
* @brief Function implementing the LED_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_LED_TaskStart */
void LED_TaskStart(void const * argument)
{
  /* USER CODE BEGIN LED_TaskStart */
  /* Infinite loop */
  for(;;)
  {
	  HAL_GPIO_TogglePin(LED0_GPIO_Port,LED0_Pin);
    osDelay(100);
  }
  /* USER CODE END LED_TaskStart */
}

/* CallbackTimerSensor function */
void CallbackTimerSensor(void const * argument)
{
  /* USER CODE BEGIN CallbackTimerSensor */
    BaseType_t pxHigherPriorityTaskWoken;
	uint8_t i;
	TXMSGTIM->ucMessageID++;
	for(i=0;i<20;i++)
		TXMSGTIM->ucData[i] = i+TXMSGTIM->ucMessageID;
    if(xQueueSendFromISR(myQueue05Handle,(void*)&TXMSGTIM,&pxHigherPriorityTaskWoken) == errQUEUE_FULL)//������з�������
	{
		printf("myQueue05Handle errQUEUE_FULL\r\n");
	}
	else
		printf("myQueue05Handle xQueueSend [ OK ] TXMSGTIM->ucMessageID = %d\r\n",TXMSGTIM->ucMessageID);
	printf("CallbackTimerSensor\r\n");
    portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
    osTimerStop(TimerSensorHandle);
  /* USER CODE END CallbackTimerSensor */
}

/* Callback02 function */
void Callback02(void const * argument)
{
  /* USER CODE BEGIN Callback02 */
  
  /* USER CODE END Callback02 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void my01_TaskStart(void const * argument)
{
	for(;;)
	{
		osSemaphoreWait(myBinarySem01Handle, osWaitForever);
		printf("osSemaphoreWait(myBinarySem01Handle) [ OK ];\r\n");    
		osDelay(10);
	}
}

void my02_TaskStart(void const * argument)
{

	uint8_t pvBuffer ;

	uint8_t i = 0;
	for(;;)
	{
		if(xQueueReceive( myQueue01Handle, (void *) &pvBuffer, 10) == pdPASS)  
		{
			printf("myQueue01Handle get keyval %03d \r\n",pvBuffer);
			
		}
		if(xQueueReceive( myQueue02Handle, (void*)&RXMSG, 10) == pdPASS)
		{
			printf("\r\n myQueue02Handle xQueueReceive [ OK ]");
			printf("\r\nRXMSG->ucMessageID = %d \r",RXMSG->ucMessageID);
			printf("RXMSG->ucData[0] = ");
			for(i=0;i<20;i++)
				printf(" %03d",RXMSG->ucData[i]);
			printf("\r\n");
		}
		if(xQueueReceive( myQueue03Handle, (void*)&Usart1_DATA_RECV, 10) == pdPASS)
		{
			printf("Usart1_DATA_RECV->RX_flag = %d RX_Size = %d RX_pData = ",Usart1_DATA_RECV->RX_flag,Usart1_DATA_RECV->RX_Size);
			for(uint8_t i=0;i<Usart1_DATA_RECV->RX_Size;i++)
			{
				printf(" %c",Usart1_DATA_RECV->RX_pData[i]);
			}
			printf("\n");	
		}
		if(xQueueReceive( myQueue05Handle, (void*)&RXMSG, 10) == pdPASS)
		{
			printf("\r\nx myQueue05Handle QueueReceive [ OK ]");
			printf("\r\nRXMSG->ucMessageID = %d \r",RXMSG->ucMessageID);
			printf("RXMSG->ucData[0] = ");
			for(i=0;i<20;i++)
				printf(" %03d",RXMSG->ucData[i]);
			printf("\r\n");
		
		}
		
		HAL_GPIO_TogglePin(LED1_GPIO_Port,LED1_Pin);
//		osDelay(10);
	}
}
uint8_t Get_Key_Value(void)
{
	if(HAL_GPIO_ReadPin(KEY0_GPIO_Port, KEY0_Pin) == 0)
	{
		osDelay(20);
		if(HAL_GPIO_ReadPin(KEY0_GPIO_Port, KEY0_Pin) == 0)
			return 1;
	}
	if(HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin) == 0)
	{
		osDelay(20);
		if(HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin) == 0)
			return 2;
	}
	if(HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin) == 0)
	{
		osDelay(20);
		if(HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin) == 0)
			return 3;
	}
	if(HAL_GPIO_ReadPin(KEY_UP_GPIO_Port, KEY_UP_Pin) == 1)
	{
		osDelay(20);
		if(HAL_GPIO_ReadPin(KEY_UP_GPIO_Port, KEY_UP_Pin) == 1)
			return 4;
	}
	return 0;
}
void Show_SYS_INFO_Task(void)
{
	uint8_t pcWriteBuffer[200];
	printf("=================================================\r\n"); 
	printf("\r\ntask_name  \tstate\tprior\tstack\t Id\r\n");
	vTaskList((char *)&pcWriteBuffer);
	printf("%s\r\n", pcWriteBuffer);

	printf("\r\ntask_name     time_count(10us) usage_pec\r\n");
	vTaskGetRunTimeStats((char *)&pcWriteBuffer);
	printf("%s\r\n", pcWriteBuffer);

}	     
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
