/***********************************************************************************
 * 文 件 名   : bsp_usart.h
 * 负 责 人   : jishubao
 * 创建日期   : 2019年3月6日
 * 文件描述   : bsp_usart.c 的头文件
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/

#ifndef __BSP_USART_H__
#define __BSP_USART_H__

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "main.h"
#include "usart.h"
#include "cmsis_os.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */
/* BEGIN Private defines */
#define DEBUG_PRINTF_DEF	
#define DEBUG_PRINTF printf
#define RX_LEN 1024  
#define TX_LEN 100	 
typedef struct  
{  
    uint8_t  RX_flag:1;        //IDLE receive flag
    uint8_t  TX_flag:1;        //IDLE send flag
    uint16_t RX_Size;          //receive length
    uint8_t  RX_pData[RX_LEN]; //DMA receive buffer
}USART_RECEIVETYPE;  
typedef struct AMessage
{
    char ucMessageID;
    char ucData[ 20 ];
}MSG;
extern USART_RECEIVETYPE UsartTypeInit;
extern USART_RECEIVETYPE *UsartType; 
extern USART_RECEIVETYPE *UsartTypeRecv;
extern USART_RECEIVETYPE Usart2Type;   
extern USART_RECEIVETYPE Usart3Type; 
extern USART_RECEIVETYPE Usart4Type; 
extern USART_RECEIVETYPE Usart5Type;  
extern uint8_t recvfromPCbuf[RX_LEN];//上位机通信串口接收缓存

extern osMessageQId myQueue01Handle;
extern osMessageQId myQueue02Handle;
extern osMessageQId myQueue03Handle;
extern osMessageQId myQueue04Handle;
extern osMessageQId myQueue05Handle;
/* END Private defines */


void Analysis_Serial_Data(void);
void Enable_BSP_USART_IT(void);
uint8_t USART1_Send_DMA(uint8_t *data,uint8_t len);
uint8_t USART1_Read_DMA(uint8_t *data,uint8_t *len);
uint8_t USART2_Send_DMA(uint8_t *data,uint8_t len);
uint8_t USART2_Read_DMA(uint8_t *data,uint8_t *len);
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart);
void UsartReceive_IDLE(UART_HandleTypeDef *huart);
uint8_t PC_Data_Analysis(uint8_t *recvfromPCbuf);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
#endif

