/***********************************************************************************
 * 文 件 名   : bsp_timer.c
 * 负 责 人   : jishubao
 * 创建日期   : 2019年3月6日
 * 文件描述   : 板载定时器功能
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/
#include "bsp_timer.h"
#include "bsp_usart.h"

volatile unsigned long  ulHighFrequencyTimerTicks = 0ul;

MSG DATAMSG_ISR;
MSG * TXMSG_ISR =&DATAMSG_ISR;
uint16_t cnt_tim6 = 0;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

	BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
   if(htim==(&htim5))//任务运行次数定时器时间到
	{
		ulHighFrequencyTimerTicks++;
	}
//	if(htim==(&htim6))//任务运行次数定时器时间到
//	{
////		 printf("\rhtim6 %d\r\n",cnt_tim6++);
////		BaseType_t pxHigherPriorityTaskWoken;
////		uint8_t i;
////		TXMSG_ISR->ucMessageID++;
////		for(i=0;i<20;i++)
////			TXMSG_ISR->ucData[i] = i+TXMSG_ISR->ucMessageID;
////		xQueueSendFromISR(myQueue05Handle,(void*)&TXMSG_ISR,&pxHigherPriorityTaskWoken);//向队列中发送数据
////		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
//	}

}

