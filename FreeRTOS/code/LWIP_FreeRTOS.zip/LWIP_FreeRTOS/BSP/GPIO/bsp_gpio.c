/* Includes ------------------------------------------------------------------*/
#include "bsp_gpio.h"
#include "motor_control.h"


/*****************************************************************************
 * 函 数 名  : Mode_Select
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 控制模式判断
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Mode_Select(void)
{
//    if(AUTOMODE)
//    {
//        Mode_CTL_TO_PS2();  //PS2遥控手柄模式
//    }
//    else 
//    {
//        Mode_CTL_TO_PC();   //PC机控制模式
//    }
	Mode_CTL_TO_PC();   //PC机控制模式
        
}
/*****************************************************************************
 * 函 数 名  : Set_Yuntai
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 设置云台状态
 * 输入参数  : s8 cmd  云台控制命令
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Set_Yuntai(u8 cmd)
{
//    if(cmd == 0x01) //开启云台
//        YUNTAI_ON;
//    else            //关闭云台
//        YUNTAI_OFF;

}

/*****************************************************************************
 * 函 数 名  : Set_Alarm
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 设置报警灯状态
 * 输入参数  : s8 cmd  报警灯控制命令
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Set_Alarm(u8 cmd)
{
//    switch ( cmd )
//    {
//        case BJ_CMD_RED_ONLY ://只开启状态灯红灯
//            BJ_RED_ON;
//            BJ_GREEN_OFF;
//            BJ_YELLOW_OFF;
//            break;
//        case BJ_CMD_GREEN_ONLY ://只开启状态灯绿灯
//            BJ_GREEN_ON;
//            BJ_RED_OFF;
//            BJ_YELLOW_OFF;
//            break;
//        case BJ_CMD_YELLOW_ONLY ://只开启状态灯黄灯
//            BJ_YELLOW_ON;
//            BJ_RED_OFF;
//            BJ_GREEN_OFF;
//            break;
//        default:                    //cmd非法，只开启状态灯绿灯
//            BJ_GREEN_ON;
//            BJ_RED_OFF;
//            BJ_YELLOW_OFF;
//            break;
//    }
}

/*****************************************************************************
 * 函 数 名  : Wireless_Charging_Status
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 无线充电状态设置
 * 输入参数  : s8 cmd  无线充电控制命令
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
u8 Wireless_Charging_Status(u8 cmd)
{

//    if(cmd ==0x00) WXCD_EN=0;       //无线充电开关关闭
//    else if(cmd == 0x01)WXCD_EN=1;  //无线充电开关打开，开始充电
    return 0;
}

void LimitSwitch_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
	
	GPIO_InitStruct.Pin = LIMIT_DOWN_SW_Pin|LIMIT_UP_SW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(LIMIT_DOWN_SW_Port, &GPIO_InitStruct);
	HAL_GPIO_WritePin(LIMIT_DOWN_SW_Port,LIMIT_DOWN_SW_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LIMIT_UP_SW_Port,LIMIT_UP_SW_Pin,GPIO_PIN_SET);
	
}

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
