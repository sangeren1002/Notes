﻿/***********************************************************************************
 * 文 件 名   : bsp_SR04M.c
 * 负 责 人   : jishubao
 * 创建日期   : 2019年2月20日
 * 文件描述   : SR04M超声波驱动文件
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/

#include "bsp_SR04M.h"
#include "bsp_usart.h"
#include "stm32f4xx_hal.h"

/* 请求超声波数据的CMD */
const u8 cmdbuf[10] = {0x7f, 0x01, 0x12, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x16};

HAL_StatusTypeDef Get_Ultrasonic_Sensor_Distance(u16 *dis)
{
/* add begin by jishubao, 2019-02-20, Mantis号:2 原因:最好放在定时器中断中发送 */
	//Send_SR04M_CMD((u8*)cmdbuf,LEN_SR04M_CMD);
/* add end by jishubao, 2019-02-20 */
	 if(UsartType.RX_flag) 	 // Receive flag
	 {	
		 UsartType.RX_flag=0;	 // clean flag
		 if(UsartType.RX_pData[0]==0x7f&&UsartType.RX_pData[1]==0x01)
		 {
   			*dis = UsartType.RX_pData[4]<<8 | UsartType.RX_pData[5];//距离单位为mm
		 }
		 return HAL_OK;
	 }
	 else
	 	return HAL_ERROR; 	

}
HAL_StatusTypeDef Send_SR04M_CMD(u8 *cmd,u8 len)
{
//	char *usart1buf;
//	memcpy(usart1buf,cmd,len);
	if(HAL_UART_STATE_READY == huart1.gState )
	{ 
		if (HAL_UART_Transmit_DMA(&huart1, (u8*)cmdbuf, 10) != HAL_OK)
		{
			/* Transfer error in transmission process */                                                                                  
			Error_Handler();   
		}
	}
	return HAL_OK;
}
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

