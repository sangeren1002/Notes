/***********************************************************************************
 * 文 件 名   : bsp_timer.h
 * 负 责 人   : jishubao
 * 创建日期   : 2019年3月6日
 * 文件描述   : bsp_timer.c 的头文件
 * 版权说明   : Copyright (c) 2008-2019   杭州国辰机器人科技有限公司
 * 其    他   : 
 * 修改日志   : 
***********************************************************************************/

#ifndef __BSP_TIMER_H__
#define __BSP_TIMER_H__
#include "stm32f4xx_hal.h"
#include "tim.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */
#define DEBUG_FRE_TEST_TIM3 

typedef struct{
 int32_t loopnum;
 uint32_t pusecount;
 uint32_t truepuse;
}PUSEEncoder;
extern PUSEEncoder mypuse;	
#define ENCODER_LINE                        2500
#define TIM_ENCODERMODE_TIx                 TIM_ENCODERMODE_TI12
#define ENCODER_TIM_PERIOD                  0xFFFF
#define CNT_MAX                             0xFFFF
#if (TIM_ENCODERMODE_TIx == TIM_ENCODERMODE_TI12)
  #define ENCODER_RESOLUTION                (4*ENCODER_LINE)//4倍频,同时使用CH1,CH2
#else 
#if ((TIM_ENCODERMODE_TIx == TIM_ENCODERMODE_TI2)||(TIM_ENCODERMODE_TIx==TIM_ENCODERMODE_TI1))
    #define ENCODER_RESOLUTION              (2*ENCODER_LINE)//2倍频,只使用CH1或者CH2
#endif
#endif
void Get_Encoder_AB_Values(void);
void user_pwm_setvalue(uint16_t value,uint32_t chanenel);
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __BSP_TIMER_H__ */

