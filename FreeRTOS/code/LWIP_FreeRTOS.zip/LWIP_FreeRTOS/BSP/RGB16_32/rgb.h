#ifndef _RGB_H
#define _RGB_H
#include "sys_config.h"

#define MYBOARD_RGB
#ifdef MYBOARD_RGB

#define DISP2_ON        HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_RESET)
#define DISP2_OFF       HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_SET)

#define CLK2_TOGGLE    HAL_GPIO_TogglePin(RGB_PIN_SCK_GPIO_Port, RGB_PIN_SCK_Pin)
#define CLK_TOGGLE 	   HAL_GPIO_WritePin(RGB_PIN_SCK_GPIO_Port, RGB_PIN_SCK_Pin,GPIO_PIN_SET);HAL_GPIO_WritePin(GPIOE, RGB_PIN_SCK_Pin,GPIO_PIN_RESET)

#define STROBE2          //m1_le_1; m1_le_0
#define STROBE		HAL_GPIO_WritePin(RGB_PIN_STR_GPIO_Port, RGB_PIN_STR_Pin,GPIO_PIN_SET);HAL_GPIO_WritePin(RGB_PIN_STR_GPIO_Port, RGB_PIN_STR_Pin,GPIO_PIN_RESET)


#define  SET_RGB_PIN_R1(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_R1_GPIO_Port,RGB_PIN_R1_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_R1_GPIO_Port,RGB_PIN_R1_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_G1(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_G1_GPIO_Port,RGB_PIN_G1_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_G1_GPIO_Port,RGB_PIN_G1_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_B1(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_B1_GPIO_Port,RGB_PIN_B1_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_B1_GPIO_Port,RGB_PIN_B1_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_R2(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_R2_GPIO_Port,RGB_PIN_R2_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_R2_GPIO_Port,RGB_PIN_R2_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_G2(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_G2_GPIO_Port,RGB_PIN_G2_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_G2_GPIO_Port,RGB_PIN_G2_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_B2(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_B2_GPIO_Port,RGB_PIN_B2_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_B2_GPIO_Port,RGB_PIN_B2_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_A(n)      	n==1?HAL_GPIO_WritePin(RGB_PIN_A_GPIO_Port,RGB_PIN_A_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_A_GPIO_Port,RGB_PIN_A_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_B(n)      	n==1?HAL_GPIO_WritePin(RGB_PIN_B_GPIO_Port,RGB_PIN_B_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_B_GPIO_Port,RGB_PIN_B_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_C(n)      	n==1?HAL_GPIO_WritePin(RGB_PIN_C_GPIO_Port,RGB_PIN_C_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_C_GPIO_Port,RGB_PIN_C_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_SCK(n)     n==1?HAL_GPIO_WritePin(RGB_PIN_SCK_GPIO_Port,RGB_PIN_SCK_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_SCK_GPIO_Port,RGB_PIN_SCK_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_STR(n)     n==1?HAL_GPIO_WritePin(RGB_PIN_STR_GPIO_Port,RGB_PIN_STR_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_STR_GPIO_Port,RGB_PIN_STR_Pin,GPIO_PIN_RESET)
#define  SET_RGB_PIN_OE(n)      n==1?HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_RESET)

#define	OE_H	HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_SET)
#define	SCK_H	HAL_GPIO_WritePin(RGB_PIN_SCK_GPIO_Port,RGB_PIN_SCK_Pin,GPIO_PIN_SET)
#define	LE_H	HAL_GPIO_WritePin(RGB_PIN_STR_GPIO_Port,RGB_PIN_STR_Pin,GPIO_PIN_SET)
#define	A_H		HAL_GPIO_WritePin(RGB_PIN_A_GPIO_Port,RGB_PIN_A_Pin,GPIO_PIN_SET)
#define	B_H		HAL_GPIO_WritePin(RGB_PIN_B_GPIO_Port,RGB_PIN_B_Pin,GPIO_PIN_SET)
#define	C_H		HAL_GPIO_WritePin(RGB_PIN_C_GPIO_Port,RGB_PIN_C_Pin,GPIO_PIN_SET)
#define	R1_H	HAL_GPIO_WritePin(RGB_PIN_R1_GPIO_Port,RGB_PIN_R1_Pin,GPIO_PIN_SET)
#define	R2_H	HAL_GPIO_WritePin(RGB_PIN_R2_GPIO_Port,RGB_PIN_R2_Pin,GPIO_PIN_SET)
#define	G1_H	HAL_GPIO_WritePin(RGB_PIN_G1_GPIO_Port,RGB_PIN_G1_Pin,GPIO_PIN_SET)
#define	G2_H	HAL_GPIO_WritePin(RGB_PIN_G2_GPIO_Port,RGB_PIN_G2_Pin,GPIO_PIN_SET)
#define	B1_H	HAL_GPIO_WritePin(RGB_PIN_B1_GPIO_Port,RGB_PIN_B1_Pin,GPIO_PIN_SET)
#define	B2_H	HAL_GPIO_WritePin(RGB_PIN_B2_GPIO_Port,RGB_PIN_B2_Pin,GPIO_PIN_SET)
#define	H_H		//HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_SET)


#define	OE_L	HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_RESET)
#define	SCK_L	HAL_GPIO_WritePin(RGB_PIN_SCK_GPIO_Port,RGB_PIN_SCK_Pin,GPIO_PIN_RESET)
#define	LE_L	HAL_GPIO_WritePin(RGB_PIN_STR_GPIO_Port,RGB_PIN_STR_Pin,GPIO_PIN_RESET)
#define	A_L		HAL_GPIO_WritePin(RGB_PIN_A_GPIO_Port,RGB_PIN_A_Pin,GPIO_PIN_RESET)
#define	B_L		HAL_GPIO_WritePin(RGB_PIN_B_GPIO_Port,RGB_PIN_B_Pin,GPIO_PIN_RESET)
#define	C_L		HAL_GPIO_WritePin(RGB_PIN_C_GPIO_Port,RGB_PIN_C_Pin,GPIO_PIN_RESET)
#define	R1_L	HAL_GPIO_WritePin(RGB_PIN_R1_GPIO_Port,RGB_PIN_R1_Pin,GPIO_PIN_RESET)
#define	R2_L	HAL_GPIO_WritePin(RGB_PIN_R2_GPIO_Port,RGB_PIN_R2_Pin,GPIO_PIN_RESET)
#define	G1_L	HAL_GPIO_WritePin(RGB_PIN_G1_GPIO_Port,RGB_PIN_G1_Pin,GPIO_PIN_RESET)
#define	G2_L	HAL_GPIO_WritePin(RGB_PIN_G2_GPIO_Port,RGB_PIN_G2_Pin,GPIO_PIN_RESET)
#define	B1_L	HAL_GPIO_WritePin(RGB_PIN_B1_GPIO_Port,RGB_PIN_B1_Pin,GPIO_PIN_RESET)
#define	B2_L	HAL_GPIO_WritePin(RGB_PIN_B2_GPIO_Port,RGB_PIN_B2_Pin,GPIO_PIN_RESET)
#define	H_L		//HAL_GPIO_WritePin(RGB_PIN_OE_GPIO_Port,RGB_PIN_OE_Pin,GPIO_PIN_RESET)

#endif

#ifndef MYBOARD_RGB
#define RGB_PIN_R1 		GPIO_PIN_2
#define RGB_PIN_G1 		GPIO_PIN_3
#define RGB_PIN_B1 		GPIO_PIN_4

#define RGB_PIN_R2 		GPIO_PIN_5
#define RGB_PIN_G2 		GPIO_PIN_6
#define RGB_PIN_B2 		GPIO_PIN_7

#define RGB_PIN_A 		GPIO_PIN_0
#define RGB_PIN_B 		GPIO_PIN_1
#define RGB_PIN_C 		GPIO_PIN_2

#define RGB_PIN_SCK 	GPIO_PIN_3
#define RGB_PIN_STR 	GPIO_PIN_4
#define RGB_PIN_OE 		GPIO_PIN_5

#define RGB_PORT_G 		GPIOG
#define RGB_PORT_F 		GPIOF
#endif
#define MAX_light 64  

#define MATRIX_WIDTH    32
#define MATRIX_HEIGHT   16
#define MATRIX_MODULE   32

#define MATRIX_SIZE     MATRIX_WIDTH*MATRIX_HEIGHT



#define X_max 32  //X������
#define Y_max 16  //Y������
#define LED_byte ((X_max/8)*Y_max*2)//16X32Ϊ128bit
#define Red    0  //����ɫ
#define Green  1  //����ɫ
#define Orgen  2  //����ɫ



#define light 3     //�������� 

#ifndef MYBOARD_RGB
#define DISP2_ON        HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_RESET)
#define DISP2_OFF       HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_SET)

#define CLK2_TOGGLE    HAL_GPIO_TogglePin(RGB_PORT_F, RGB_PIN_SCK)
#define CLK_TOGGLE 	   HAL_GPIO_WritePin(RGB_PORT_F, RGB_PIN_SCK,GPIO_PIN_SET);HAL_GPIO_WritePin(RGB_PORT_F, RGB_PIN_SCK,GPIO_PIN_RESET)

#define STROBE2          //m1_le_1; m1_le_0
#define STROBE		HAL_GPIO_WritePin(RGB_PORT_F, RGB_PIN_STR,GPIO_PIN_SET);HAL_GPIO_WritePin(RGB_PORT_F, RGB_PIN_STR,GPIO_PIN_RESET)


#define  SET_RGB_PIN_R1(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_R1,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_R1,GPIO_PIN_RESET)
#define  SET_RGB_PIN_G1(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_G1,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_G1,GPIO_PIN_RESET)
#define  SET_RGB_PIN_B1(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B1,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B1,GPIO_PIN_RESET)
#define  SET_RGB_PIN_R2(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_R2,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_R2,GPIO_PIN_RESET)
#define  SET_RGB_PIN_G2(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_G2,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_G2,GPIO_PIN_RESET)
#define  SET_RGB_PIN_B2(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B2,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B2,GPIO_PIN_RESET)
#define  SET_RGB_PIN_A(n)      	n==1?HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_A,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_A,GPIO_PIN_RESET)
#define  SET_RGB_PIN_B(n)      	n==1?HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B,GPIO_PIN_RESET)
#define  SET_RGB_PIN_C(n)      	n==1?HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_C,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_C,GPIO_PIN_RESET)
#define  SET_RGB_PIN_SCK(n)     n==1?HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_SCK,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_SCK,GPIO_PIN_RESET)
#define  SET_RGB_PIN_STR(n)     n==1?HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_STR,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_STR,GPIO_PIN_RESET)
#define  SET_RGB_PIN_OE(n)      n==1?HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_SET):HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_RESET)

#define	OE_H	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_OE,GPIO_PIN_SET)
#define	SCK_H	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_SCK,GPIO_PIN_SET)
#define	LE_H	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_STR,GPIO_PIN_SET)
#define	A_H		HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_A,GPIO_PIN_SET)
#define	B_H		HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B,GPIO_PIN_SET)
#define	C_H		HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_C,GPIO_PIN_SET)
#define	R1_H	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_R1,GPIO_PIN_SET)
#define	R2_H	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_R2,GPIO_PIN_SET)
#define	G1_H	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_G1,GPIO_PIN_SET)
#define	G2_H	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_G2,GPIO_PIN_SET)
#define	B1_H	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B1,GPIO_PIN_SET)
#define	B2_H	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B2,GPIO_PIN_SET)
#define	H_H		//HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_SET)


#define	OE_L	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_OE,GPIO_PIN_RESET)
#define	SCK_L	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_SCK,GPIO_PIN_RESET)
#define	LE_L	HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_STR,GPIO_PIN_RESET)
#define	A_L		HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_A,GPIO_PIN_RESET)
#define	B_L		HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_B,GPIO_PIN_RESET)
#define	C_L		HAL_GPIO_WritePin(RGB_PORT_G,RGB_PIN_C,GPIO_PIN_RESET)
#define	R1_L	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_R1,GPIO_PIN_RESET)
#define	R2_L	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_R2,GPIO_PIN_RESET)
#define	G1_L	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_G1,GPIO_PIN_RESET)
#define	G2_L	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_G2,GPIO_PIN_RESET)
#define	B1_L	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B1,GPIO_PIN_RESET)
#define	B2_L	HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_B2,GPIO_PIN_RESET)
#define	H_L		//HAL_GPIO_WritePin(RGB_PORT_F,RGB_PIN_OE,GPIO_PIN_RESET)
#endif

typedef enum rotationDegrees {
		rotation0,
		rotation90,
	  rotation180,
		rotation270
} rotationDegrees;

#ifndef Color888
#define Color888(r, g, b)  (((u32)r << 16) | ((u32)g << 8) | (u32)b)
#endif

#define COLOR_BLACK   Color888(  0,   0,   0)
#define COLOR_RED     Color888(255,   0,   0)
#define COLOR_GREEN   Color888(  0, 255,   0)
#define COLOR_BLUE    Color888(  0,   0, 255)
#define COLOR_LGREEN  Color888(  0,  80,   0)
#define COLOR_WHITE   Color888(255, 255, 255)
#define COLOR_CYAN    Color888(  0, 255, 255)
#define COLOR_ORANGE  Color888(255, 165,   0)
#define COLOR_YELLOW  Color888(255, 255,   0)
#define COLOR_PURPLE  Color888(160,  32, 240)

#define COLOR_LGRAY   Color888(155, 155, 155)
#define COLOR_GRAY    Color888(127, 127, 127)
#define COLOR_DGRAY   Color888( 58,  58,  58)
#define COLOR_DDGRAY  Color888( 40,  40,  40)

#define COLOR_AQUAMARINE    0x7FFFD4   //����ɫ
#define COLOR_AZURE         0xF0FFFF   //����ɫ
#define COLOR_BEIGE         0xF5F5DC   //��ɫ
#define COLOR_CADETBLUE     0x5F9EA0   //����ɫ
#define COLOR_GOLD          0xFFD700   //��ɫ

extern u8 Red_Write  [MAX_light/8] ;    //����  
extern u8 Green_Write[MAX_light/8] ;  
extern u8 Blue_Write [MAX_light/8] ; 
extern const u8 Imagelove[][34];
#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

#ifndef _swap_int8_t
#define _swap_int8_t(a, b) { int8_t t = a; a = b; b = t; }
#endif




s8 _abs(s8 n);
void MY_RGB_Init(void);
void RGB_Init(void);
void display_PWM(void) ;
void Picture16X32(char *str);
void LED_dot_write(uint8_t x,uint8_t y,uint8_t colour,uint8_t aa);
void drawPixel(s8 x, s8 y, u32 Color);
void show_Image(const u8 *image);
void setRow(u8 row);
void drawImage(u8 x, u8 y, u32 Color, const u8 *addres);
void ClearBuff(u16 num1, u16 num2);
void drawCircle(s8 x0, s8 y0, s8 r, u32 color);
void drawLine(s8 x0, s8 y0, s8 x1, s8 y1, u32 Color);
void love(void);
void drawFastVLine(s8, s8, s8, u32);

void drawFastHLine(s8, s8, s8, u32);

void drawRect(s8, s8, s8, s8, u32);

void fillRect(s8 x, s8 y ,s8 w, s8 h, u32 Color);
void fillScreen(u32 Color);

void drawCircle(s8 x0, s8 y0, s8 r, u32 Color);

void drawCircleHelper(s8 x0, s8 y0, s8 r, s8 cornername,	u32 Color);

void fillCircleHelper(s8 x0, s8 y0, s8 r, s8 cornername,	s8 delta, u32 Color);

void fillCircle(s8 x0, s8 y0, s8 r, u32 color);

void drawTriangle(s8 x0, s8 y0, s8 x1, s8 y1,	s8 x2, s8 y2, u32 Color);

void fillTriangle(s8 x0, s8 y0, s8 x1, s8 y1, s8 x2, s8 y2, u32 Color);
void drawRoundRect(s8 x0, s8 y0, s8 w, s8 h,	s8 radius, u32 Color);

void fillRoundRect(s8 x0, s8 y0, s8 w, s8 h,	s8 radius, u32 Color);

void fillScreen(u32 Color);
void DrawOval(s8 x0, s8 y0, s8 r1, s8 r2,u32 color);
void draw_heart_blank(u32 color);
void draw_heart_full(u32 color);
void lcd_draw_image(const unsigned char *pic);
 void drawImage(u8 x, u8 y, u32 Color, const u8 *addres);
 void Eyes_Change(u8 tim,u8 flag);
#endif
