﻿#include "sys_config.h"
#include "bsp_usart.h"
#include "bsp_timer.h"
#include "bsp_can.h"
#include "bsp_gpio.h"
#include "ps2.h"
#include "adc.h"
#include "delay.h"
#include "motor_control.h"
#include "CANOpenObjDictConfig.h"

void SelfExamination_LiftPlatform(void);
extern u16 adc_value_buff[ADC_CHANNEL_CNT*ADC_CHANNEL_FRE];
/*****************************************************************************
 * 函 数 名  : Enable_BSP_IT
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 使能板级已配置中断
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Enable_BSP_IT(void)
{
    /* 开启定时器中断 */
    HAL_TIM_Base_Start_IT(&htim3);
	
	 /*  使能定时器编码器模式开始中断 */
	HAL_TIM_Encoder_Start_IT(&htim8, TIM_CHANNEL_1|TIM_CHANNEL_2);
    /* 设置tim4的计数开始值 */
    __HAL_TIM_SetCounter(&htim8,0); 
	mypuse.pusecount = 0;

    /* 清除串口空闲中断标志 */
    __HAL_UART_CLEAR_IDLEFLAG(&huart1);
    __HAL_UART_CLEAR_IDLEFLAG(&huart2);
    __HAL_UART_CLEAR_IDLEFLAG(&huart3);
    __HAL_UART_CLEAR_IDLEFLAG(&huart4);
    __HAL_UART_CLEAR_IDLEFLAG(&huart5);

    /* 配置非阻塞模式下串口 DMA接收 */
    HAL_UART_Receive_DMA(&huart1, UsartType.RX_pData, RX_LEN);
    HAL_UART_Receive_DMA(&huart2, Usart2Type.RX_pData, RX_LEN); 
    HAL_UART_Receive_DMA(&huart3, Usart3Type.RX_pData, RX_LEN);
    HAL_UART_Receive_DMA(&huart4, Usart4Type.RX_pData, RX_LEN);
    HAL_UART_Receive_DMA(&huart5, Usart5Type.RX_pData, RX_LEN);

    /* 使能串口空闲中断 */
    __HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&huart4, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&huart5, UART_IT_IDLE);
    
	HAL_ADC_Start_DMA(&hadc3,(uint32_t*) &adc_value_buff, (ADC_CHANNEL_CNT*ADC_CHANNEL_FRE));


#if DEF_DEBUG_CFG & DEF_DEBUG_PRINTF
	DEBUG_PRINTF("[ OK ] Enable_BSP_IT success ...\r\n");
#endif
	
}

/*****************************************************************************
 * 函 数 名  : BSP_SYS_Init
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 板级外设初始化
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void BSP_SYS_Init(void)
{
    Enable_BSP_IT();    //使能板级外设配置中断
		LimitSwitch_Init();
		HAL_Delay(5000);
		HAL_Delay(5000);
    CanopenInit();  //CANopen初始化

	SetCanopenParameter(0);
  SetCanopenParameter(1);
	SetCanopenParameter(2);
	
	MotorInit();
	SelfExamination_LiftPlatform();
//	PS2_Init();
#if DEBUG_PROTECT_IO
	while(PZ_CHECK == 1)	//碰撞开关检测
	{
		MotionHalts();
		AbnormalReporting(0x02,0x02,0x02);//上报异常	
	}
	while(EMERSTOP == 1)	//急停开关检测
	{
		MotionHalts();
		AbnormalReporting(0x02,0x02,0x01);//上报异常
	}
	if(PZ_CHECK == 0 && EMERSTOP == 0) //无异常后亮绿灯
	{
		Set_Alarm(BJ_CMD_GREEN_ONLY);
	}
#if DEF_DEBUG_CFG & DEF_DEBUG_PRINTF	
	DEBUG_PRINTF("[ OK ] PZ_CHECK & EMERSTOP success ...\r\n");
#endif
#endif
	Set_Alarm(BJ_CMD_GREEN_ONLY);
    //__HAL_IWDG_START(&hiwdg);
    //printf("HAL_IWDG_START\r\n");
}
/*****************************************************************************
 * 函 数 名  : Run_SYS
 * 负 责 人  : jishubao
 * 创建日期  : 2019年4月11日
 * 函数功能  : 系统运行
 * 输入参数  : void  无
 * 输出参数  : 无
 * 返 回 值  : 
 * 调用关系  : 
 * 其    它  : 

*****************************************************************************/
void Run_SYS(void)
{
    Mode_Select();       
    HAL_Delay(2);
}
void SelfExamination_LiftPlatform(void)
{	
	u32 timcnt;
	timcnt = 0;
	SetSpeed_UP_DOWN((float)3.0);
	while(LIMIT_UP_SW == 0 && timcnt<10)
	{
		HAL_Delay(1000);
		timcnt++;
	}
	SetSpeed_UP_DOWN((float)-3.0);
	while(LIMIT_DOWN_SW ==0 );
}




//#ifdef  USE_FULL_ASSERT
////当编译提示出错的时候此函数用来报告错误的文件和所在行
////file：指向源文件
////line：指向在文件中的行数
//void assert_failed(uint8_t* file, uint32_t line)
//{ 
//	while (1)
//	{
//	}
//}
//#endif

////THUMB指令不支持汇编内联
////采用如下方法实现执行汇编指令WFI  
//__asm void WFI_SET(void)
//{
//	WFI;		  
//}
////关闭所有中断(但是不包括fault和NMI中断)
//__asm void INTX_DISABLE(void)
//{
//	CPSID   I
//	BX      LR	  
//}
////开启所有中断
//__asm void INTX_ENABLE(void)
//{
//	CPSIE   I
//	BX      LR  
//}
////设置栈顶地址
////addr:栈顶地址
//__asm void MSR_MSP(u32 addr) 
//{
//	MSR MSP, r0 			//set Main Stack value
//	BX r14
//}
