﻿#ifndef __BMS_H
#define __BMS_H 
#include "sys_config.h"
//#include "rs485.h"


typedef struct{
    u16  voltage;   //电压
    u16  current;   //电流
    u8  remaining_battery_percentage;   //剩余电量百分比
    u16  total_capacity;    //总容量
    u16  remaining_total_capacity;  //剩余容量
    u8  chargingstatus;     //充电状态
    u16  charging_times;    //完全充放电次数 
}BattaryMSG;


extern BattaryMSG battarymsg;

void BattaryMSGAnalysis(u8 *rs485buf,BattaryMSG *battarymsg);
void RequestBatteryInformation(BattaryMSG *msg);
#endif	   
















