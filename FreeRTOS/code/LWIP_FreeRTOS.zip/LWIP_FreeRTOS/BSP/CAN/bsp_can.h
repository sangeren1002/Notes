﻿#ifndef __BSP_CAN_H
#define __BSP_CAN_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "main.h"
#include "sys_config.h"


/* USER CODE BEGIN Includes */
#include "applicfg.h"
#include "bsp_timer.h"
#include "can.h"
/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */

/* 设置波特率 CAN1挂载AHB1 42M BAUDRATE = 42M /((1+6+7)*N)*/
#define CAN_BAUD_1M    3
#define CAN_BAUD_500K  6


 typedef struct{
	Message m;
}CANOpen_Message;

typedef struct
{
	uint8_t Data[8];
}CAN_Msgdata;
extern Message RxMSG;
/* USER CODE END Private defines */


/* USER CODE BEGIN Prototypes */
u8 canInit(void);
void CAN_Filter_Init(void);
void CAN_Init(void);
u8 canSend(CAN_HandleTypeDef *hcan,Message *m);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif
#endif /*__ pinoutConfig_H */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
