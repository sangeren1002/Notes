/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2019 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */     
#include "lwip.h"
#include "app.h"
#include "bsp_usart.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
volatile unsigned long  ulHighFrequencyTimerTicks = 0ul;
/* USER CODE END Variables */
osThreadId InitTaskHandle;
osThreadId LEDTaskHandle;
osThreadId AppDebugTaskHandle;
osThreadId AppControlTaskHandle;
osThreadId AppLWIPTaskHandle;
osMessageQId USART1QueueHandle;
osMessageQId USART3QueueHandle;
osMessageQId NETQueueHandle;
osMutexId PrintfMutexHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
 void Show_SYS_INFO_Task(void);  
/* USER CODE END FunctionPrototypes */

void StartInitTask(void const * argument);
void StartLEDTask(void const * argument);
void StartAppDebugTask(void const * argument);
void StartAppControlTask(void const * argument);
void StartAppLWIPTask(void const * argument);

extern void MX_LWIP_Init(void);
void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void configureTimerForRunTimeStats(void);
unsigned long getRunTimeCounterValue(void);

/* USER CODE BEGIN 1 */
/* Functions needed when configGENERATE_RUN_TIME_STATS is on */
__weak void configureTimerForRunTimeStats(void)
{
	ulHighFrequencyTimerTicks = 0ul;
}

__weak unsigned long getRunTimeCounterValue(void)
{
	return ulHighFrequencyTimerTicks;;
}
/* USER CODE END 1 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
       
  /* USER CODE END Init */

  /* Create the mutex(es) */
  /* definition and creation of PrintfMutex */
  osMutexDef(PrintfMutex);
  PrintfMutexHandle = osMutexCreate(osMutex(PrintfMutex));

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of InitTask */
  osThreadDef(InitTask, StartInitTask, osPriorityLow, 0, 256);
  InitTaskHandle = osThreadCreate(osThread(InitTask), NULL);

  /* definition and creation of LEDTask */
  osThreadDef(LEDTask, StartLEDTask, osPriorityBelowNormal, 0, 128);
  LEDTaskHandle = osThreadCreate(osThread(LEDTask), NULL);

  /* definition and creation of AppDebugTask */
  osThreadDef(AppDebugTask, StartAppDebugTask, osPriorityBelowNormal, 0, 512);
  AppDebugTaskHandle = osThreadCreate(osThread(AppDebugTask), NULL);

  /* definition and creation of AppControlTask */
  osThreadDef(AppControlTask, StartAppControlTask, osPriorityAboveNormal, 0, 512);
  AppControlTaskHandle = osThreadCreate(osThread(AppControlTask), NULL);

  /* definition and creation of AppLWIPTask */
  osThreadDef(AppLWIPTask, StartAppLWIPTask, osPriorityAboveNormal, 0, 512);
  AppLWIPTaskHandle = osThreadCreate(osThread(AppLWIPTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Create the queue(s) */
  /* definition and creation of USART1Queue */
/* what about the sizeof here??? cd native code */
  osMessageQDef(USART1Queue, 10, uint32_t);
  USART1QueueHandle = osMessageCreate(osMessageQ(USART1Queue), NULL);

  /* definition and creation of USART3Queue */
/* what about the sizeof here??? cd native code */
  osMessageQDef(USART3Queue, 10, uint32_t);
  USART3QueueHandle = osMessageCreate(osMessageQ(USART3Queue), NULL);

  /* definition and creation of NETQueue */
/* what about the sizeof here??? cd native code */
  osMessageQDef(NETQueue, 10, uint32_t);
  NETQueueHandle = osMessageCreate(osMessageQ(NETQueue), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
}

/* USER CODE BEGIN Header_StartInitTask */
/**
  * @brief  Function implementing the InitTask thread.
  * @param  argument: Not used 
  * @retval None
  */
/* USER CODE END Header_StartInitTask */
void StartInitTask(void const * argument)
{
  /* init code for LWIP */
  MX_LWIP_Init();

  /* USER CODE BEGIN StartInitTask */
	App_init();
	Enable_BSP_IT();
  /* Infinite loop */
  for(;;)
  {

//        App_process();

    osDelay(10);
  }
  /* USER CODE END StartInitTask */
}

/* USER CODE BEGIN Header_StartLEDTask */
/**
* @brief Function implementing the LEDTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartLEDTask */
void StartLEDTask(void const * argument)
{
  /* USER CODE BEGIN StartLEDTask */
  /* Infinite loop */
  for(;;)
  {
	HAL_GPIO_TogglePin(LED0_GPIO_Port,LED0_Pin);
    osDelay(100);
  }
  /* USER CODE END StartLEDTask */
}

/* USER CODE BEGIN Header_StartAppDebugTask */
/**
* @brief Function implementing the AppDebugTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartAppDebugTask */
void StartAppDebugTask(void const * argument)
{
  /* USER CODE BEGIN StartAppDebugTask */
  /* Infinite loop */
  for(;;)
  {
	  Show_SYS_INFO_Task();
    osDelay(10000);
  }
  /* USER CODE END StartAppDebugTask */
}

/* USER CODE BEGIN Header_StartAppControlTask */
/**
* @brief Function implementing the AppControlTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartAppControlTask */
void StartAppControlTask(void const * argument)
{
  /* USER CODE BEGIN StartAppControlTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartAppControlTask */
}

/* USER CODE BEGIN Header_StartAppLWIPTask */
/**
* @brief Function implementing the AppLWIPTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartAppLWIPTask */
void StartAppLWIPTask(void const * argument)
{
  /* USER CODE BEGIN StartAppLWIPTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartAppLWIPTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void Show_SYS_INFO_Task(void)
{
	uint8_t pcWriteBuffer[300];
	printf("\r\n============= START SYSTEM TASK INFO TASK ==========\r\n"); 
	printf("\r\ntask_name\tstate\tprior\tstack\tId\r\n");
	vTaskList((char *)&pcWriteBuffer);
	printf("%s\r\n", pcWriteBuffer);

//	printf("\r\ntask_name\t\tcnt(10us)\tusage_pec\r\n");
//	vTaskGetRunTimeStats((char *)&pcWriteBuffer);
//	printf("%s\r\n", pcWriteBuffer);
//	printf("============= END SYSTEM TASK INFO TASK ============\r\n"); 

}     
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
